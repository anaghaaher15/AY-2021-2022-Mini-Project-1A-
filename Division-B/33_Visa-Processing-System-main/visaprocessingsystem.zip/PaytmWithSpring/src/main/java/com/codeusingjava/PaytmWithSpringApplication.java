package com.codeusingjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaytmWithSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaytmWithSpringApplication.class, args);
	}

	

}

package application;

public class WelcomePage {

}

package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JOptionPane;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.scene.Scene;
public class Fresher  
{
	TextField projectText;
	TextField objectivesText;
	TextField languageText;
	
	public Scene getScene() {
	//Text nameLabel = new Text("Name");
	//TextField nameText = new TextField();
	Text projectLabel = new Text("Project Name You Worked ");
	 projectText = new TextField();
	Text objectivesLabel = new Text("Description Of Your Project ");
	TextField objectivesText = new TextField();
	Text languageLabel = new Text("Which Language You Worked In Project ");
	TextField languageText = new TextField();
	Button skills = new Button("Skills");
	 Button Previous = new Button("Back");
	 Button savel = new Button("Save"); 
	  
	  
	  Previous.setOnAction(new EventHandler<ActionEvent>(){
    	  @Override
    	  public void handle(ActionEvent actionEvent) {
    		  changeScenesback4a();
    	  }
	  });
	  savel.setOnAction(new EventHandler<ActionEvent>(){
    	  @Override
    	  public void handle(ActionEvent actionEvent) {
	  
    		  String p = projectText.getText();
    		  String o = objectivesText.getText();
    		  String l = languageText.getText();
    		  
    		  try
    		  {
    			  Class.forName("com.mysql.jdbc.Driver");
    			  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hitesh","root","");
    			  
    			  String query="insert into  project values('"+ p +"','"+ o +"','"+ l +"')";
    			PreparedStatement ps=con.prepareStatement(query);
    			ps.executeUpdate(); 
    			
    			
    			JOptionPane.showMessageDialog(null, "Saved");
    				  con.close();
    				  
    				  
    			 
    			}
    		  catch(Exception ex) 
    		  {
    			  System.out.println("errorrrrr "+ex);
    			  
    		  }
    		  
	  
    	  }
	  });
	  
	 GridPane gridPane = new GridPane(); 
	 gridPane.setMinSize(1600, 700);
     gridPane.setPadding(new Insets(10, 10, 10, 10));
     gridPane.setVgap(40);
      gridPane.setHgap(40);
      gridPane.setAlignment(Pos.BOTTOM_CENTER); 
      gridPane.setAlignment(Pos.CENTER);// BOTTOM_
    // gridPane.setAlignment(Pos.TOP_CENTER);
      
      gridPane.add(projectLabel, 0, 0); 
      gridPane.add(projectText, 1, 0);
      projectText.setMinWidth(500);   
      projectText.setMinHeight(70);; 
      gridPane.add(objectivesLabel, 0, 1); 
      gridPane.add(objectivesText, 1, 1);
      objectivesText.setMinWidth(500);   
      objectivesText.setMinHeight(70);; 
      gridPane.add(languageLabel, 0, 2); 
      gridPane.add(languageText, 1, 2);
      languageText.setMinWidth(500);   
      languageText.setMinHeight(70);; 
      gridPane.add(Previous, 1,4 );
      gridPane.add(savel, 0, 6);  
      projectLabel.setStyle("-fx-font: normal bold 23px 'serif' ");
      objectivesLabel.setStyle("-fx-font: normal bold 23px 'serif' ");
      languageLabel.setStyle("-fx-font: normal bold 23px 'serif' ");
      Previous.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
      gridPane.add(skills, 0, 4);
      skills.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
      savel.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
      
    //image creation
	    Image im = new Image("C:\\Users\\User\\Documents\\ph.jpg");
	    // create a background image
	    BackgroundImage bi = new BackgroundImage(im,
	    BackgroundRepeat.NO_REPEAT,
	    BackgroundRepeat.NO_REPEAT,
	    BackgroundPosition.DEFAULT,
	    new BackgroundSize(1.0, 1.0, true, true, false, false));
	    // Background creation
	    Background bg = new Background(bi);
	 // set background
	    gridPane.setBackground(bg);
	    
	    skills.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	  				        if(projectText.getText().isEmpty()) {
	  				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
	  				            "Form Error!", "Please enter your name");
	  				            return;
	  				        }
	  				        
	  				        if(objectivesText.getText().isEmpty()) {
	  				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
	  				            "Form Error!", "Field Cannot be blank");
	  				            return;
	  				        }
	  				      if(languageText.getText().isEmpty()) {
	  				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
	  				            "Form Error!", "Field Cannot be blank");
	  				            return;
	  				        }
	  				       
	  				      changeScenes10();
	    		  
	    	  }
	      });
	    
      Scene scene = new Scene(gridPane); 
      return scene; 
	}
	private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
	    Alert alert = new Alert(alertType);
	    alert.setTitle(title);
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.initOwner(owner);
	    alert.show();
	}
	private void changeScenes10() {
	  	  Skills details1 =new Skills();
	  	  Scene scene =details1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  }
	private void changeScenesback4a() {
		 WorkExperience   w1 =new  WorkExperience  ();
	  	  Scene scene =w1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  } 
}

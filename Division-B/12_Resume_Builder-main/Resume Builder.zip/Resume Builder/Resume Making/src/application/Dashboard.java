package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Dashboard  {
	
	 
	public Scene getScene()  
	{
		 
		VBox box=addVBox();
		BorderPane border = new BorderPane();
		border.setLeft(addVBox());
		//image creation
	    Image im = new Image("C:\\Users\\User\\Documents\\robot.jpg");
	    // create a background image
	    BackgroundImage bi = new BackgroundImage(im,
	    BackgroundRepeat.NO_REPEAT,
	    BackgroundRepeat.NO_REPEAT,
	    BackgroundPosition.DEFAULT,
	    new BackgroundSize(1.0, 1.0, true, true, false, false));
	    // Background creation
	    Background bg = new Background(bi);
	 // set background
	    
		border.setBackground(bg);
		// input stream creation
	    
        Scene scene=new Scene(border,1000,800);
		return scene;
	}
	public VBox addVBox(){
		Text DashboardLabel = new Text("Dashboard");
		DashboardLabel.setStyle("-fx-font: normal bold 30px 'serif' ");
		//Label DashboardLabel=new Label("Dashboard");
		Button CreateResume=new Button("Create Resume");
		CreateResume.setMaxWidth(700D);
		Button ResumeTemplates=new Button("Resume Templates");
		ResumeTemplates.setMaxWidth(700D);
		Button EditResume=new Button("Edit Resume");
		EditResume.setMaxWidth(700D);
		CreateResume.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenes3();
	    		  
	    	  }
	      });
		
		/*ResumeTemplates.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenes2();
	    	  }
	      });*/
		/*EditResume.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenes2();
	    	  }
	      });*/
		VBox vbox=new VBox(10,DashboardLabel,CreateResume,ResumeTemplates,EditResume);
		vbox.setAlignment(Pos.BASELINE_LEFT);
		vbox.setMargin(CreateResume,new Insets(5,5,5,5));
		vbox.setMargin(ResumeTemplates,new Insets(5,5,5,5));
		vbox.setMargin(EditResume,new Insets(5,5,5,5));
		vbox.setMargin(DashboardLabel,new Insets(5,5,5,5));
		vbox.setStyle("-fx-border-color:black");
		return vbox;
	      
		
	}
	
	private void changeScenes3() {
	  	  PersonalDetails details1 =new PersonalDetails();
	  	  Scene scene =details1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  }

}

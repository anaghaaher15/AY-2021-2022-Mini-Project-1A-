package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JOptionPane;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.scene.text.Text; 
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets; 
import javafx.geometry.Pos; 
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.control.ToggleButton; 
public class Experienced 
{   
	
	TextField employerText;
	 TextField jobText ;
	 TextField cityText;
	 TextField stateText; 
	 DatePicker startdatesPicker;
	 DatePicker  enddatesPicker;
	 TextField descriptionText;
	
	
	 public Scene getScene() 
	 {
	
		 Text employerLabel = new Text("Employer"); 
	
		  employerText = new TextField(); 
		 
		 Text jobLabel = new Text("Job title"); 
			
		 jobText = new TextField();
		 
		 Text cityLabel = new Text("city"); 
			
		 cityText = new TextField();
		 
		 Text stateLabel = new Text("State"); 
			
		  stateText = new TextField();
		 
		 Text startdatesLabel = new Text("Start date"); 
		 
		  startdatesPicker = new DatePicker();
		 
		  Text enddatesLabel = new Text("End date"); 
			 
		   enddatesPicker = new DatePicker();
		  
		  
		  CheckBox jobworkCheckBox = new CheckBox(" I Presently Work Here "); 
	      jobworkCheckBox.setIndeterminate(false); 
		  
		  
		  Text descriptionLabel = new Text(" Job Description"); 
			 
		   descriptionText = new TextField();
		  
		  
		  
		  
		  Button save = new Button("Save"); 
	      
		  Button skills = new Button("Skills");
		  Button Previous = new Button("Back");
		  
		  Previous.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenesback4b();
	    	  }
		  });
		  
		  
	    	
    	  save.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    	String e = employerText.getText();	
	    	String j = jobText.getText();	
	    	String c = cityText.getText();	
	    	String s = stateText.getText();	
	    	String dtp1=startdatesPicker.getValue().toString();	
	    	String dtp2=enddatesPicker.getValue().toString();	
	    	String desc =descriptionText.getText();
	    	
	    	try
			  {
				  Class.forName("com.mysql.jdbc.Driver");
				  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hitesh","root","");
				  
				  String query="insert into experienced values('"+ e +"','"+ j +"','"+ c +"','"+ s +"','"+ dtp1 +"','"+ dtp2 +"','"+ desc +"')";
				PreparedStatement ps=con.prepareStatement(query);
				ps.executeUpdate(); 
				
				
				JOptionPane.showMessageDialog(null, "Saved");
					  con.close();
					  
					  
				 
				}
			  catch(Exception ex) 
			  {
				  System.out.println("errorrrrr "+ex);
				  
			  }
	    	
	    	  }
    	  });
		  
	      
		 GridPane gridPane = new GridPane(); 
		 
		gridPane.setMinSize(1500, 800);//600 600
	    gridPane.setPadding(new Insets(10, 10, 10, 10));
	     gridPane.setVgap(10);
	      gridPane.setHgap(10);
	      gridPane.setAlignment(Pos.BOTTOM_RIGHT); 
	      gridPane.setAlignment(Pos.TOP_CENTER); 
		 gridPane.add(employerLabel, 0, 0); 
	      gridPane.add(employerText, 0, 1); 
	      employerLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      gridPane.add(jobLabel, 0, 3); 
	      gridPane.add(jobText, 0, 4);
	      jobLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      gridPane.add(cityLabel, 0, 5); 
	      gridPane.add(cityText, 0, 6); 
	      cityLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      gridPane.add(stateLabel, 0, 7); 
	      gridPane.add(stateText, 0, 8); 
	      stateLabel.setStyle("-fx-font: normal bold 15px 'serif' ");
	      gridPane.add(startdatesLabel, 0, 9); 
	      gridPane.add(startdatesPicker, 0, 10);
	      startdatesLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      gridPane.add(enddatesLabel, 0, 11); 
	      gridPane.add(enddatesPicker, 0, 12);
	      enddatesLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      gridPane.add(jobworkCheckBox, 0,13 ); 
	      gridPane.add(descriptionLabel, 0, 15); 
	      gridPane.add(descriptionText, 0, 16); 
	      descriptionLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      gridPane.add(save, 18, 18); 
	      save.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
	      gridPane.add(skills, 18, 19);
	      skills.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
	      gridPane.add(Previous, 20,20 );
	      Previous.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
	      
	    //image creation
		    Image im = new Image("C:\\Users\\User\\Documents\\ph.jpg");
		    // create a background image
		    BackgroundImage bi = new BackgroundImage(im,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundPosition.DEFAULT,
		    new BackgroundSize(1.0, 1.0, true, true, false, false));
		    // Background creation
		    Background bg = new Background(bi);
		 // set background
		    gridPane.setBackground(bg);
		    
		    skills.setOnAction(new EventHandler<ActionEvent>(){
		    	  @Override
		    	  public void handle(ActionEvent actionEvent) {
		    		  if(employerText.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Field cannot be blank");
				            return;
				        }
				        
				        if(jobText.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Field Cannot be blank");
				            return;
				        }
				        if(cityText.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Field Cannot be blank");
				            return;
				        }
				        if(stateText.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Field Cannot be blank");
				            return;
				        }
				        if(descriptionText.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Field Cannot be blank");
				            return;
				        }
				        
		    		  changeScenes9();
		    		  
		    	  }
		      });
		    
	      Scene scene = new Scene(gridPane); 
	      return scene;
	 }
	 private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
		    Alert alert = new Alert(alertType);
		    alert.setTitle(title);
		    alert.setHeaderText(null);
		    alert.setContentText(message);
		    alert.initOwner(owner);
		    alert.show();
		}
	 private void changeScenes9() {
	  	  Skills details1 =new Skills();
	  	  Scene scene =details1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  }
	 private void changeScenesback4b() {
		 WorkExperience   w1 =new  WorkExperience  ();
	  	  Scene scene =w1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  } 
}

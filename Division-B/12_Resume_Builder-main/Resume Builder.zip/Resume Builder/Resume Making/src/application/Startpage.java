package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Startpage extends Application {
	
	private static Stage stage;
	
	public static Stage getStage() {
        return stage;
    }
	
	@Override
	
	public void start(Stage stage) throws IOException {
		this.stage=stage;
		Button SignUp = new Button("SignUp");
	    Button SignIn = new Button("SignIn");
	   // Text nameLabel = new Text("Make a great \n resume. Simply");
	    SignUp.setMaxSize(100, 200);
	    SignIn.setMaxSize(100, 200);
	    HBox hbox = new HBox(20, SignUp, SignIn);
	   // HBox hbox1 = new HBox(20, nameLabel);
	    
	    hbox.setSpacing(50);
	    HBox.setMargin(SignUp, new Insets(10, 10, 10, 10));
	    HBox.setMargin(SignIn, new Insets(10, 10, 10, 10));
	   // HBox.setMargin(nameLabel, new Insets(0,0,0,50));
	    hbox.setAlignment(Pos.TOP_RIGHT);
	   // hbox1.setAlignment(Pos.TOP_LEFT);
	    hbox.setBackground(new Background(new BackgroundFill(Color.HOTPINK,null,null)));
	    //hbox1.setBackground(new Background(new BackgroundFill(Color.WHEAT,null,null)));
	 // input stream creation
	    FileInputStream inp = new FileInputStream("C:\\Users\\User\\Documents\\welcomepage.jpg");
	    //image creation
	    Image im = new Image(inp);
	    // create a background image
	    BackgroundImage bi = new BackgroundImage(im,
	    BackgroundRepeat.NO_REPEAT,
	    BackgroundRepeat.NO_REPEAT,
	    BackgroundPosition.DEFAULT,
	    new BackgroundSize(1.0, 1.0, true, true, false, false));
	    // Background creation
	    Background bg = new Background(bi);
	    
	    

	    //ImageView imageView = new ImageView(image);
	    BorderPane bPane = new BorderPane();
	    bPane.setTop(hbox);
	    //bPane.setRight(imageView);

	 // set background
	    bPane.setBackground(bg); 
	    
	    SignIn.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenesLogin();
	    	  }
	      });
	    
	    SignUp.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenesRegister();
	    	  }
	      });
	    
	    Scene scene = new Scene(bPane,1000,800); 
	       
	      //Setting title to the Stage 
	      stage.setTitle("Resume Builder"); 
	         
	      //Adding scene to the stage 
	      stage.setScene(scene);
	      stage.setWidth(1300);
	      stage.setHeight(700);
	      //Displaying the contents of the stage 
	      //stage.hide();
	      stage.show();
	    
	}
	private void changeScenesLogin()  {
	  	  LoginPage login=new LoginPage();
	  	  Scene scene=login.getScene();
	  	  getStage().setScene(scene);
	    }
	private void changeScenesRegister() {
		Registration registration=new Registration();
	  	  Scene scene=registration.getScene();
	  	  getStage().setScene(scene);
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}

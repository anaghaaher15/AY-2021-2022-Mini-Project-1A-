package application;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Iterator;

import javax.swing.JOptionPane;

import javafx.application.Application; 
import javafx.collections.FXCollections; 
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets; 
import javafx.geometry.Pos; 

import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button; 
import javafx.scene.control.CheckBox; 
import javafx.scene.control.ChoiceBox; 
import javafx.scene.control.DatePicker; 
import javafx.scene.control.ListView; 
import javafx.scene.control.RadioButton;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text; 
import javafx.scene.control.TextField; 
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.control.ToggleButton; 
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.scene.text.Text; 
import javafx.scene.control.TextField; 
import javafx.scene.control.ToggleGroup;  
import javafx.scene.control.ToggleButton; 
import javafx.stage.Stage; 
public class PersonalDetails  
{
	
	TextField nameText;
	DatePicker datePicker;
	RadioButton maleRadio;
	 RadioButton femaleRadio ;
	 TextField technologiesText;
	 ObservableList<String> names;
	 ChoiceBox locationchoiceBox ;
	 TextField addressText;
	 TextField mobileText1;
	 TextField mobileText2;
	 TextField emailText;
	 ListView<String> educationListView ;
	public Scene getScene() 
	{
		 Text nameLabel = new Text("Name"); 
		  nameText = new TextField(); 
		 Text dobLabel = new Text("Date of birth"); 
		 datePicker = new DatePicker();
		  Text genderLabel = new Text("gender"); 
		  ToggleGroup groupGender = new ToggleGroup(); 
		   maleRadio = new RadioButton("male"); 
		  femaleRadio = new RadioButton("female"); 
		  maleRadio.setToggleGroup(groupGender); 
		  femaleRadio.setToggleGroup(groupGender);
		  Text technologiesLabel = new Text("Technologies Known");
		   technologiesText = new TextField(); 
		 // CheckBox javaCheckBox = new CheckBox("Java"); 
	      //javaCheckBox.setIndeterminate(false); 
	      //CheckBox pythonCheckBox = new CheckBox("Python\n"); 
	      //javaCheckBox.setIndeterminate(false); 
	      //CheckBox dotnetCheckBox = new CheckBox("DotNet"); 
	      //javaCheckBox.setIndeterminate(false); 
	      //CheckBox machinelearningCheckBox = new CheckBox("MACHINE LEARNING "); 
	      //javaCheckBox.setIndeterminate(false); 
	      Text educationLabel = new Text("Educational qualification"); 
	       names = FXCollections.observableArrayList( 
	    	         "Engineering", "MCA", "MBA", "Graduation", "MTECH", "Mphil", "Phd"); 
	    	      educationListView= new ListView<String>(names); 
	    	      Text locationLabel = new Text("location");
	    	       locationchoiceBox = new ChoiceBox(); 
	    	      locationchoiceBox.getItems().addAll
	    	         ("Hyderabad", "Chennai", "Delhi", "Mumbai", "Vishakhapatnam"); 
	    	      Text addressLabel = new Text("Address");
	    	       addressText = new TextField();
	    	      Text mobileLabel = new Text("Mobile Number ");
	    	       mobileText1 = new TextField();
	    	      Text alternateLabel = new Text(" Alternate Mobile Number ");
	    	       mobileText2= new TextField();

	    	      
	    	      Text emailLabel = new Text("Email Id"); 
	    		  emailText = new TextField(); 
	    		  
	    	      
	    	      
	    	  Button save0 = new Button("Save"); 
	    	
	    	  save0.setOnAction(new EventHandler<ActionEvent>(){
		    	  @Override
		    	  public void handle(ActionEvent actionEvent) {
		    		  
		    		  //JOptionPane.showMessageDialog(null,"hello");
		    		  
		String n= nameText.getText();   
		String t= technologiesText.getText(); 
		String a= addressText.getText(); 
		String m1= mobileText1.getText();
		String m2= mobileText2.getText();
		String e1= emailText.getText();	  
		    	String g1="";
		    	if(maleRadio.isSelected())
		    	{
		    	g1="Male";	
		    	}
		    	
		    	if(femaleRadio.isSelected())
		    	{
		    	g1="female";	
		    	}
		    	String q="";
		    String ii=educationListView.getSelectionModel().getSelectedItem().toString();
		    
		    
		   String loc= locationchoiceBox.getSelectionModel().getSelectedItem().toString();
		    		  
		String dtp=	datePicker.getValue().toString();	   
		   
		//JOptionPane.showMessageDialog(null, n+" "+t+" "+a+" "+m1+" "+m2+" "+e1+" "+g1+" "+q+" "+loc+" "+dtp+" "+ii);
		
		
		try
		  {
			  Class.forName("com.mysql.jdbc.Driver");
			  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hitesh","root","");
			  
			  String query="insert into personaldetails values('"+ n +"','"+ dtp +"','"+ g1 +"','"+ t +"','"+ ii +"','"+ loc +"','"+ a +"','"+ m1 +"','"+ e1 +"')";
			PreparedStatement ps=con.prepareStatement(query);
			ps.executeUpdate(); 
			
			
			JOptionPane.showMessageDialog(null, "Saved");
				  con.close();
				  
				  
			 
			}
		  catch(Exception ex) 
		  {
			  System.out.println("errorrrrr "+ex);
			  
		  }
		  
		
		
		
		    	  }
	    	  });
	    	  
	    	  Button Previous = new Button("Back");
	    	  
	    	  Button buttonQualificationDetails = new Button("Qualification Details");
	    	  
	    	  
	    	  
	    	  Previous.setOnAction(new EventHandler<ActionEvent>(){
		    	  @Override
		    	  public void handle(ActionEvent actionEvent) {
		    		  changeScenesback1();
		    	  }
	    	  });
	    	  
	    	  GridPane gridPane = new GridPane();    
	      
	      
	      gridPane.setMinSize(3000, 1000); //new 500
	       
	          
	      gridPane.setPadding(new Insets(10, 10, 10, 10));  
	      
	     
	      gridPane.setVgap(5); 
	      gridPane.setHgap(5);       
	      
	      
	      gridPane.setAlignment(Pos.CENTER ); 
	       
	      //Arranging all the nodes in the grid 
	      gridPane.add(nameLabel, 0, 0); 
	      gridPane.add(nameText, 1, 0); 
	       
	      gridPane.add(dobLabel, 0, 1);       
	      gridPane.add(datePicker, 1, 1); 
	      
	      gridPane.add(genderLabel, 0, 2); 
	      gridPane.add(maleRadio, 1, 2);       
	      gridPane.add(femaleRadio, 2, 2); 
	    //  gridPane.add(reservationLabel, 0, 3); 
	     // gridPane.add(yes, 1, 3);       
	      //gridPane.add(no, 2, 3);  
	       
	      gridPane.add(technologiesLabel, 0, 4);
	      gridPane.add(technologiesText, 1, 4); 
	    //  gridPane.add(javaCheckBox, 1, 4);       
	     // gridPane.add(dotnetCheckBox, 2, 4);  
	    //  gridPane.add(pythonCheckBox, 5,4 );  
	     // gridPane.add(machinelearningCheckBox, 8, 4);  
	       
	      gridPane.add(educationLabel, 0, 5); 
	      gridPane.add(educationListView, 1, 5);      
	       
	      gridPane.add(locationLabel, 0, 6); 
	      gridPane.add(locationchoiceBox, 1, 6);    
	      gridPane.add(addressLabel, 0, 7); 
	      gridPane.add( addressText, 1, 7);
	      addressText.setMinWidth(500);   
	      addressText.setMinHeight(70);; 
	      gridPane.add(mobileLabel, 0, 10); 
	      gridPane.add( mobileText1, 1, 10);
	      gridPane.add(alternateLabel, 2, 10); 
	      gridPane.add( mobileText2, 3, 10);
	      
	      
	      
	      gridPane.add(emailLabel, 0, 11); 
	      gridPane.add(emailText, 1, 11); 
	      
	      gridPane.add(Previous, 9, 11);
	      
	      gridPane.add(save0, 10, 11);      
	      
	      gridPane.add(buttonQualificationDetails, 11, 11);      
	      
	      //Styling nodes 
	      Previous.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
	      save0.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
	      buttonQualificationDetails.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;"); 
	       
	       
	       
	      nameLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      dobLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      genderLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	     
	      technologiesLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      educationLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      locationLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      addressLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      mobileLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      alternateLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      emailLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
	      //Creating a scene object 7
	      buttonQualificationDetails.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
				        if(nameText.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Please enter your name");
				            return;
				        }
				        
				        if(technologiesText.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Field Cannot be blank");
				            return;
				        }
				        changeScenes4();
				    }  
	    	  
	      });
	      
	    //image creation
		    Image im = new Image("C:\\Users\\User\\Documents\\ph.jpg");
		    // create a background image
		    BackgroundImage bi = new BackgroundImage(im,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundPosition.DEFAULT,
		    new BackgroundSize(1.0, 1.0, true, true, false, false));
		    // Background creation
		    Background bg = new Background(bi);
		 // set background
		    gridPane.setBackground(bg);
		    
	      Scene scene = new Scene(gridPane,1000,800); 
	      return scene; 
		}  
	private void changeScenes4() {
		Qualification details1 =new Qualification();
	  	  Scene scene =details1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  }  
	/*private void changeScenesback1() throws Exception {
		 Class c = Class.forName("LoginPage");  
  	     Object o= c.newInstance(); 
  	     Method m=c.getDeclaredMethod("createScenes1",null);
  	   m.setAccessible(true);  
  	    m.invoke(o, null);  
	  }*/
	private void changeScenesback1() {
		Dashboard dashboard=new Dashboard();
	  	  Scene scene=dashboard.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  } 
	private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
	    Alert alert = new Alert(alertType);
	    alert.setTitle(title);
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.initOwner(owner);
	    alert.show();
	}
	} 
	


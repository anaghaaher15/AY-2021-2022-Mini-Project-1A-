package application;
import javafx.event.ActionEvent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.scene.text.Font;
import javafx.scene.text.Text; 
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.geometry.Insets; 
import javafx.geometry.Pos;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane; 
import javafx.scene.control.PasswordField;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
public class Registration
{ 
	
	TextField name2Text;
	TextField email3textField1;
	PasswordField password2textField2;
	 PasswordField confirmPassword1;
	 TextField mobile3Text1;
	 String email;
	public Scene getScene() {
		Label RegisterLabel=new Label("Registration");
		RegisterLabel.setAlignment(Pos.CENTER);
		 Text name2Label = new Text("Name"); 
		  name2Text = new TextField(); 
		 
		 Text email3text1 = new Text("Email Id");
		 email3textField1 = new TextField();   
		email=email3textField1.getText();
		 
		//Regular Expression for email  
	    // String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}";
	     
	     //Regular Expression for password
	    // String Pattern1="\\A(?=\\S*[0-9])(?=\\S*[a-z])(?=\\S*[A-Z])(?=\\S*[@#$%^&+=])\\S{8,}\\z";
		 
		 Text password2text2 = new Text(" Create Password");
		  password2textField2 = new PasswordField();
		  String passwd=password2textField2.getText();
		  
		  Text confirmPassword = new Text(" Confirm Password");
		  confirmPassword1 = new PasswordField();
		  String confirmpassword=confirmPassword1.getText();
		  
		  Text mobile3Label = new Text("Mobile Number ");
	       mobile3Text1 = new TextField();
		  
		  
		  
		  Button save4 = new Button("Register"); 
		  
		  

			
		  Button cancel=new Button("Cancel");
		  
		  GridPane gridPane = new GridPane();    
	      
	      
	      gridPane.setMinSize(2000, 900); 
	       
	          
	      gridPane.setPadding(new Insets(10, 10, 10, 10));  
	      
	     
	      gridPane.setVgap(15); 
	      gridPane.setHgap(15);       
	      
	      
	      gridPane.setAlignment(Pos.CENTER); 
	      gridPane.setAlignment(Pos.BASELINE_LEFT);
		
	      gridPane.add(RegisterLabel, 1, 0);
	      gridPane.add(name2Label, 0, 1); 
	      gridPane.add(name2Text, 1, 1); 
		
	      gridPane.add(email3text1 , 0, 2);       
	      gridPane.add(email3textField1, 1, 2);
	      
	      
	      gridPane.add(password2text2 , 0, 3); 
	      gridPane.add( password2textField2 , 1, 3);    
	      gridPane.add(confirmPassword, 0, 4);
	      gridPane.add(confirmPassword1, 1, 4);
	      gridPane.add(mobile3Label, 0, 5);
	      gridPane.add(mobile3Text1 , 1, 5);
	    //  mobile3Text1.setMinWidth(500);   
	      //mobile3Text1.setMinHeight(50);; 
	      
	      gridPane.add(save4, 0,6 );
	      gridPane.add(cancel, 6, 6);
		
	      
	      
	      save4.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;"); 
	      cancel.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;"); 
	      
	      
	      
	      
	      name2Label.setStyle("-fx-font: normal bold 20px 'serif' "); 
	      email3text1.setStyle("-fx-font: normal bold 20px 'serif' ");  
	      password2text2 .setStyle("-fx-font: normal bold 20px 'serif' ");
	      confirmPassword.setStyle("-fx-font: normal bold 20px 'serif' ");
	      mobile3Label.setStyle("-fx-font: normal bold 20px 'serif' "); 
	      RegisterLabel.setStyle("-fx-font: normal bold 100px 'serif' ");
	      RegisterLabel.setStyle("-fx-background-color: plum; -fx-textfill: white;");
	      
	      /*Pattern emailpattern=Pattern.compile(regex);
	      Matcher emailmatcher=emailpattern.matcher(email);
	      boolean emailmatcher1=emailmatcher.matches();*/
	      
	      //Pattern pattern = Pattern.compile(Pattern1,Pattern.CASE_INSENSITIVE);
		 // Matcher passwdmatcher = pattern.matcher(passwd);
		  
		//image creation
		    Image im = new Image("C:\\Users\\User\\Documents\\istockphoto.jpg");
		    // create a background image
		    BackgroundImage bi = new BackgroundImage(im,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundPosition.DEFAULT,
		    new BackgroundSize(1.0, 1.0, true, true, false, false));
		    // Background creation
		    Background bg = new Background(bi);
		 // set background
		    gridPane.setBackground(bg);
	      

    	  save4.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	      
	    		  String n = name2Text.getText();
	    		  String e = email3textField1.getText();
	    		  String p = password2textField2.getText();
	    		 String  c= confirmPassword1.getText();
	    		 String  m=mobile3Text1.getText();
	    		 try
	   		  {
	    			 
	    			 if(name2Text.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Please enter your name");
				            return;
				        }
				        if(email3textField1.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Please enter your email id");
				            return;
				        }
				        /*if(!emailmatcher1) {
				        	 showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
							            "Form Error!", "Please enter valid email id");
				        	 return;
				        }*/
				        if(password2textField2.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Please enter a password");
				            return;
				        }
				        /*if(!(passwdmatcher.matches())) {
				        	showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
						            "Form Error!", "Please enter a valid password");
						            return;
				        }*/
				        if(confirmPassword1.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Please enter a password");
				            return;
				        }
				        /*if(!passwd.equals(confirmpassword)) {
				        	showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
						            "Form Error!", "Password not matched");
						            return;
				        }*/
				        if(mobile3Text1.getText().isEmpty()) {
				            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
				            "Form Error!", "Please enter a mobile number");
				            return;
				        }

				        else {
				    
				        	Class.forName("com.mysql.jdbc.Driver");
				        	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hitesh","root","");
	   			  
				        	String query="insert into account values('"+ n +"','"+ e +"','"+ p +"','"+ m +"')";
				        	PreparedStatement ps=con.prepareStatement(query);
				        	ps.executeUpdate(); 
				        	JOptionPane.showMessageDialog(null, "Saved");
				        	con.close();
				        }
	   		  }
	   		  catch(Exception ex) 
	   		  {
	   			  System.out.println("errorrrrr "+ex);
	   			  
	   		  }	 
	    		  
	    	  }	 
			});
    	  
    	  cancel.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenesback2();
	    		  
	    	  }
	      });
	      
	      
	      RegisterLabel.setMinWidth(500);   
	      RegisterLabel.setMinHeight(50); 
	      Scene scene = new Scene(gridPane);
	      return scene;
	}
	private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
	    Alert alert = new Alert(alertType);
	    alert.setTitle(title);
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.initOwner(owner);
	    alert.show();
	}
	private void changeScenesback2() {
		LoginPage loginpage=new LoginPage();
	  	  Scene scene=loginpage.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  } 
	}

	



package application;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JOptionPane;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos; 

import javafx.scene.text.Text; 
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.geometry.Insets; 
import javafx.geometry.Pos; 
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ToggleGroup;  
import javafx.scene.control.ToggleButton; 
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;  
public class Qualification  
{
	
	 TextField schoolText;
	 TextField city1Text;
	 TextField state1Text;
	 TextField board1Text;
	 TextField sscText ;
	 TextField college1Text;
	 TextField city2Text;
	 TextField state2Text;
	 TextField board2Text;
	 TextField hscText;
	 TextField degreeText; 
	 TextField city3Text;
	 TextField state3Text;
	 TextField universityText;
	 TextField finalresultText;
	public Scene getScene() 
	{
		 ScrollPane scrollPane = new ScrollPane();
		 
		 Text schoolLabel = new Text("School name "); 
			
		 schoolText = new TextField(); 
		 
		 Text city1Label = new Text("City "); 
			
		 city1Text = new TextField();
		
		 Text state1Label = new Text("State "); 
			
		  state1Text = new TextField();
         
		 Text board1Label = new Text("Board"); 
			
		  board1Text = new TextField();
		 
		 Text sscLabel = new Text("Percentage of Secondary School Certificate "); 
			
		  sscText = new TextField();
		 
		 
		 Text college1Label = new Text("College name "); 
			
		  college1Text = new TextField(); 
		 
		 Text city2Label = new Text("City "); 
			
		  city2Text = new TextField();
		
		 Text state2Label = new Text("State "); 
			
		  state2Text = new TextField();
         
		 Text board2Label = new Text("Board"); 
			
		 board2Text = new TextField();
		 
		 Text hscLabel = new Text("Percentage of  Higher Secondary Education "); 
			
		  hscText = new TextField();
		 
		 
		 
		 
		 Text degreeLabel = new Text("Degree college name "); 
			
		  degreeText = new TextField(); 
		 
		 Text city3Label = new Text("City "); 
			
		  city3Text = new TextField();
		
		 Text state3Label = new Text("State "); 
			
		  state3Text = new TextField();
         
		 Text universityLabel = new Text("University Name"); 
			
		 universityText = new TextField();
		 
		 Text finalresultLabel = new Text("CGPA"); 
		 
		  finalresultText = new TextField();
			
		 Button Previous1 = new Button("Back");
		 Button save2 = new Button("Save");
		 Button experience = new Button("User Experience");
		 
		 Previous1.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenesback2();
	    	  }
   	  });
		 
		
	    	
   	  save2.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  
	    		  
	    		 String st = schoolText.getText();
	    		 String c1t = city1Text.getText();
	    		 String s1t = state1Text.getText();
	    		 String b1 = board1Text.getText();
	    		 String ss = sscText.getText();
	    		 String c = college1Text.getText();
	    		 String c2t = city2Text.getText();
	    		 String s2t = state2Text.getText();
	    		 String b2 = board2Text.getText();
	    		 String hs = hscText.getText();
	    		 String d = degreeText.getText();
	    		 String c3t = city3Text.getText();
	    		 String s3t = state3Text.getText();
	    		 String un = universityText.getText();
	    		 String f = finalresultText.getText();
	    		 try
	   		  {
	   			  Class.forName("com.mysql.jdbc.Driver");
	   			  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hitesh","root","");
	   			 String query="insert into qualificationdetails values('"+ st +"','"+ c1t +"','"+ s1t +"','"+ b1 +"','"+ ss +"','"+ c +"','"+ c2t +"','"+ s2t +"','"+ b2 +"','"+ hs +"','"+ d +"','"+ c3t +"','"+ s3t +"','"+ un +"','"+ f +"')";
	   			PreparedStatement ps=con.prepareStatement(query);
				ps.executeUpdate(); 
				
				
				JOptionPane.showMessageDialog(null, "Saved");
					  con.close();
	   			  
	   		  }
	    		 catch(Exception ex)
	    		 {
	    			 System.out.println("errorrrrr "+ex);
	    		 }
   	 }
	  });
   	  
   	
		 
		 GridPane gridPane = new GridPane();    
		 gridPane.setMinSize(7000, 650);
		    gridPane.setPadding(new Insets(10, 10, 10, 10));
		     gridPane.setVgap(10);
		      gridPane.setHgap(10);
		      gridPane.setAlignment(Pos.CENTER);// BOTTOM_
		      gridPane.setAlignment(Pos.TOP_CENTER); 
		      
		      
		      gridPane.add( schoolLabel , 0, 0); 
		      gridPane.add(schoolText, 0, 1); 
		      schoolLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      gridPane.add( city1Label , 0, 2); 
		      gridPane.add(city1Text, 0, 3); 
		      city1Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		
		      
		      gridPane.add( state1Label , 0, 4); 
		      gridPane.add(state1Text, 0, 5); 
		      state1Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      gridPane.add( board1Label , 0, 6); 
		      gridPane.add(board1Text, 0, 7); 
		      board1Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      
		      gridPane.add( sscLabel , 0, 8); 
		      gridPane.add(sscText, 0, 9); 
		      sscLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      
		      
		      
		      
		      gridPane.add( college1Label , 0, 10); 
		      gridPane.add(college1Text, 0, 11); 
		      college1Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      gridPane.add( city2Label , 0, 12); 
		      gridPane.add(city2Text, 0, 13); 
		      city2Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		
		      
		      gridPane.add( state2Label , 0, 14); 
		      gridPane.add(state2Text, 0, 15); 
		      state2Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      gridPane.add( board2Label , 0, 16); 
		      gridPane.add(board2Text, 0, 17); 
		      board2Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      
		      gridPane.add( hscLabel , 0, 18); 
		      gridPane.add(hscText, 0, 19); 
		      hscLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      
		      
		      
		      gridPane.add( degreeLabel , 0, 20); 
		      gridPane.add(degreeText, 0, 21); 
		      degreeLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      gridPane.add( city3Label , 0, 22); 
		      gridPane.add(city3Text, 0, 23); 
		      city3Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		
		      
		      gridPane.add( state3Label , 0, 24); 
		      gridPane.add(state3Text, 0, 25); 
		      state3Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      gridPane.add( universityLabel , 0, 26); 
		      gridPane.add(universityText, 0, 27); 
		      universityLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      
		      gridPane.add( finalresultLabel , 0, 28); 
		      gridPane.add(finalresultText, 0, 29); 
		      finalresultLabel.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      gridPane.add(Previous1, 30, 29);
		      Previous1.setStyle("-fx-background-color: darkgreen; -fx-text-fill:white;");
		      
		      gridPane.add(save2, 30, 30); 
		      save2.setStyle("-fx-background-color:  darkgreen; -fx-text-fill: white;");
		        
		      gridPane.add(experience, 30, 31); 
		      experience.setStyle("-fx-background-color:  darkgreen; -fx-text-fill: white;");  
		      
		      gridPane.setLayoutX(5);
		      
		      experience.setOnAction(new EventHandler<ActionEvent>(){
		      	  @Override
		      	  public void handle(ActionEvent actionEvent) {
		    			        if(schoolText.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter your School");
		    			            return;
		    			        }
		    			        if(city1Text.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(state1Text.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(board1Text.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(sscText.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(college1Text.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(city2Text.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(state2Text.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(board2Text.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(hscText.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(degreeText.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(city3Text.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(state3Text.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(universityText.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        if(finalresultText.getText().isEmpty()) {
		    			            showAlert(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), 
		    			            "Form Error!", "Please enter City");
		    			            return;
		    			        }
		    			        
		    			        changeScenes5();
		    			    }  
		      	  
		        });
		      
		    //image creation
			    Image im = new Image("C:\\Users\\User\\Documents\\ph.jpg");
			    // create a background image
			    BackgroundImage bi = new BackgroundImage(im,
			    BackgroundRepeat.NO_REPEAT,
			    BackgroundRepeat.NO_REPEAT,
			    BackgroundPosition.DEFAULT,
			    new BackgroundSize(1.0, 1.0, true, true, false, false));
			    // Background creation
			    Background bg = new Background(bi);
			 // set background
			    gridPane.setBackground(bg);
		      
		      scrollPane.setContent(gridPane);
		      scrollPane.setPrefSize(100,100);
		      Scene scene = new Scene(scrollPane); 
		      
		      return scene;
		      
	}
	private void changeScenes5() {
		WorkExperience details1 =new WorkExperience();
	  	  Scene scene =details1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  } 
	
	private void changeScenesback2() {
		PersonalDetails details1 =new PersonalDetails();
	  	  Scene scene =details1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  } 
	private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
	    Alert alert = new Alert(alertType);
	    alert.setTitle(title);
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.initOwner(owner);
	    alert.show();
	}
	
}

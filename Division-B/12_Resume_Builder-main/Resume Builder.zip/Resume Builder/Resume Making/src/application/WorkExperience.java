package application;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.RadioButton;
import javafx.scene.text.Text;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets; 
import javafx.geometry.Pos; 
import javafx.scene.Scene; 
import javafx.scene.control.Button;
public class WorkExperience 
{
	 
	
	public Scene getScene()
	{
		/* Text experienceLabel = new Text("Experience"); 
		ToggleGroup groupExperience = new ToggleGroup(); 
	     RadioButton fresherRadio = new RadioButton("Fresher"); 
	     fresherRadio.setToggleGroup(groupExperience); 
	     RadioButton experiencedRadio = new RadioButton("Experienced");
	     experiencedRadio.setToggleGroup(groupExperience);*/ 
		Text workLabel = new Text("Work experience"); 
		Button buttonexperience = new Button("Experienced"); 
	     Button buttonfresher = new Button(" Fresher");
	     Button Previous = new Button("Back");
	     buttonexperience.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenes6();
	    		  
	    	  }
	      });
	     buttonfresher.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenes7();
	    		  
	    	  }
	      });
	     Previous.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenesback3();
	    	  }
   	  });
	     GridPane gridPane = new GridPane(); 
	     gridPane.setMinSize(1300, 1300); 
	     gridPane.setPadding(new Insets(10, 10, 10, 10));  
	     gridPane.setVgap(5); 
	      gridPane.setHgap(5);
	    //  gridPane.setAlignment(Pos.BOTTOM_CENTER); 
	      gridPane.setAlignment(Pos.TOP_CENTER); 
	     // gridPane.setAlignment(Pos.CENTER); 
	    //  gridPane.add(experienceLabel, 0, 2); 
	     // gridPane.add(fresherRadio, 1, 2);       
	      //gridPane.add(experiencedRadio, 2, 2);
	      //experienceLabel.setStyle("-fx-font: normal bold 15px 'serif' ");
	      gridPane.add(workLabel, 3,3);
	      gridPane.add(buttonexperience, 2, 8);
	      buttonexperience.setMinWidth(70);   
	      buttonexperience.setMinHeight(40);; 
	      gridPane.add(buttonfresher, 8, 8); 
	      buttonfresher.setMinWidth(70);   
	      buttonfresher.setMinHeight(40);;
	      gridPane.add(Previous,14,14 );
	      Previous.setMinWidth(70);   
	      Previous.setMinHeight(40);;
	      workLabel.setStyle("-fx-font: normal bold 40px 'serif' "); 
	      buttonexperience.setStyle(
	    	         "-fx-background-color: darkslateblue; -fx-text-fill: white;"); 
	     
	      buttonfresher.setStyle(
	    	         "-fx-background-color: darkslateblue; -fx-text-fill: white;"); 
	      
	      Previous.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
	      
	    //image creation
		    Image im = new Image("C:\\Users\\User\\Documents\\workexp.jpg");
		    // create a background image
		    BackgroundImage bi = new BackgroundImage(im,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundPosition.DEFAULT,
		    new BackgroundSize(1.0, 1.0, true, true, false, false));
		    // Background creation
		    Background bg = new Background(bi);
		 // set background
		    gridPane.setBackground(bg);
		    
	      Scene scene = new Scene(gridPane); 
	      return scene; 
	     
	} 
	private void changeScenes6() {
		Experienced details1 =new Experienced();
	  	  Scene scene =details1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene); 
}
	private void changeScenes7() {
		Fresher details1 =new Fresher();
	  	  Scene scene =details1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene); 
}
	
	private void changeScenesback3() {
		Qualification  q1 =new Qualification ();
	  	  Scene scene =q1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  } 
}

package application;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JOptionPane;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.text.Text; 
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets; 
import javafx.geometry.Pos; 
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.control.ToggleButton; 
public class Skills 
{
	
	 TextField skill1Text;
	 ChoiceBox rating1choiceBox;
	 TextField skill2Text;
	 ChoiceBox rating2choiceBox;
	 TextField skill3Text;
	 ChoiceBox rating3choiceBox; 
	 
	 
	 public Scene getScene() 
	 {
		 Text skill1Label = new Text("Skill"); 
			
		skill1Text = new TextField(); 
		  
		 Text rating1Label = new Text("Level");
				 
				 
		  rating1choiceBox = new ChoiceBox(); 
	      rating1choiceBox.getItems().addAll
	         ("Novice", "Beginner", "Skillfull", "Experienced", "Expert"); 
	 
		 Text skill2Label = new Text("Skill"); 
			
		  skill2Text = new TextField();
		 Text rating2Label = new Text("Level");
		 rating2choiceBox = new ChoiceBox(); 
	      rating2choiceBox.getItems().addAll
	         ("Novice", "Beginner", "Skillfull", "Experienced", "Expert"); 
	 
		 
		 Text skill3Label = new Text("Skill"); 
			
		  skill3Text = new TextField(); 
		 Text rating3Label = new Text("Level");
		  rating3choiceBox = new ChoiceBox(); 
	      rating3choiceBox.getItems().addAll
	         ("Novice", "Beginner", "Skillfull", "Experienced", "Expert"); 
		 
		 
		 
	      Button save1 = new Button("Save"); 
		 
		 
	      Button create = new Button("Create Resume"); 
		 
	      Button Previous = new Button("Back");	 
	      Previous.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenesback5();
	    	  }
   	  });
		 
	      save1.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	     
	    		  String s1 = skill1Text.getText();
	    		  String roc1= rating1choiceBox.getSelectionModel().getSelectedItem().toString();
	    		  String s2 = skill2Text.getText();
	    		  String roc2= rating2choiceBox.getSelectionModel().getSelectedItem().toString();
	    		  String s3 = skill3Text.getText();
	    		  String roc3= rating3choiceBox.getSelectionModel().getSelectedItem().toString();
	    		  
	    		  try
	    		  {
	    			  Class.forName("com.mysql.jdbc.Driver");
	    			  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hitesh","root","");
	    			  
	    			  String query="insert into skill values('"+ s1 +"','"+ roc1 +"','"+ s2 +"','"+ roc2 +"','"+ s3 +"','"+ roc3 +"')";
	    			PreparedStatement ps=con.prepareStatement(query);
	    			ps.executeUpdate(); 
	    			
	    			
	    			JOptionPane.showMessageDialog(null, "Saved");
	    				  con.close();
	    				  
	    				  
	    			 
	    			}
	    		  catch(Exception ex) 
	    		  {
	    			  System.out.println("errorrrrr "+ex);
	    			  
	    		  }
	    		  
	    		  
	    		  
	    		  
	    	  }
    	  });
		 
		 GridPane gridPane = new GridPane(); 
		 
			gridPane.setMinSize(1500, 800);
		    gridPane.setPadding(new Insets(10, 10, 10, 10));
		     gridPane.setVgap(10);
		      gridPane.setHgap(10);
		     // gridPane.setAlignment(Pos.BOTTOM_RIGHT);
		      gridPane.setAlignment(Pos.CENTER);
		      gridPane.setAlignment(Pos.TOP_CENTER);
		      gridPane.setAlignment(Pos.TOP_CENTER);
		      gridPane.add( skill1Label , 0, 0); 
		      gridPane.add(skill1Text, 0, 1); 
		      skill1Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      gridPane.add(rating1Label, 0, 2); 
		      gridPane.add(rating1choiceBox, 0, 3); 
		      rating1Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      gridPane.add( skill2Label , 0, 4); 
		      gridPane.add(skill2Text, 0, 5); 
		      skill2Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      gridPane.add(rating2Label, 0, 6); 
		      gridPane.add(rating2choiceBox, 0, 7); 
		      rating2Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      gridPane.add( skill3Label , 0, 8); 
		      gridPane.add(skill3Text, 0, 9); 
		      skill3Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      gridPane.add(rating3Label, 0, 10); 
		      gridPane.add(rating3choiceBox, 0, 11); 
		      rating3Label.setStyle("-fx-font: normal bold 15px 'serif' "); 
		      
		      
		      
		      gridPane.add(save1, 13, 13); 
		      save1.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
		      
		      
		      gridPane.add(create, 13, 14); 
		      create.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
		      
		    //image creation
			    Image im = new Image("C:\\Users\\User\\Documents\\ph.jpg");
			    // create a background image
			    BackgroundImage bi = new BackgroundImage(im,
			    BackgroundRepeat.NO_REPEAT,
			    BackgroundRepeat.NO_REPEAT,
			    BackgroundPosition.DEFAULT,
			    new BackgroundSize(1.0, 1.0, true, true, false, false));
			    // Background creation
			    Background bg = new Background(bi);
			 // set background
			    gridPane.setBackground(bg);
			    
		      gridPane.add(Previous, 20,20 );
		      Previous.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;");
		      Scene scene = new Scene(gridPane); 
		      return scene;
	 }  
	 private void changeScenesback5() {
		 WorkExperience   w1 =new  WorkExperience  ();
	  	  Scene scene =w1.getScene();
	  	  
	  	Startpage.getStage().setScene(scene);
	  } 
 
}

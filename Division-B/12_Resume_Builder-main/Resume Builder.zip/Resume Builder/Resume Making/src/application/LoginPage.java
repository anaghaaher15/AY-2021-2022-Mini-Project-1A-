package application;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

import static javafx.application.Application.launch;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class LoginPage  {
	//private static Stage stage;
	private boolean inValid=false;
	private boolean textField1Validation;
	private boolean textField2Validation;
	
	public Scene getScene()   {
		// TODO Auto-generated method stub
		 //creating label email 
	      Text text1 = new Text("Email");       
	      
	      //creating label password 
	      Text text2 = new Text("Password"); 
	       
	      //Creating Text Filed for email        
	      TextField textField1 = new TextField();       
	      
	      //Creating Text Filed for password        
	      PasswordField textField2 = new PasswordField();  
	      
	      //Creating Buttons 
	      Button button1 = new Button("Login"); 
	      Button button2 = new Button("Register");  
	      
	      //Creating a Grid Pane 
	      GridPane gridPane = new GridPane();    
	      
	      //Setting size for the pane 
	      gridPane.setMinSize(200, 200); 
	      
	      //Setting the padding  
	      gridPane.setPadding(new Insets(10, 10, 10, 10)); 
	      
	      //Setting the vertical and horizontal gaps between the columns 
	      gridPane.setVgap(5); 
	      gridPane.setHgap(5);       
	      
	      //Setting the Grid alignment 
	      gridPane.setAlignment(Pos.CENTER_LEFT); 
	       
	      //Arranging all the nodes in the grid 
	      gridPane.add(text1, 0, 0); 
	      gridPane.add(textField1, 1, 0); 
	      gridPane.add(text2, 0, 1);       
	      gridPane.add(textField2, 1, 1); 
	      gridPane.add(button1, 0, 2); 
	      gridPane.add(button2, 1, 2); 
	      
	      
	   // input stream creation
		   // FileInputStream inp = new FileInputStream("C:\\Users\\User\\Documents\\pages.jpg");
		    //image creation
		    Image im = new Image("C:\\Users\\User\\Documents\\istockphoto.jpg");
		    // create a background image
		    BackgroundImage bi = new BackgroundImage(im,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundRepeat.NO_REPEAT,
		    BackgroundPosition.DEFAULT,
		    new BackgroundSize(1.0, 1.0, true, true, false, false));
		    // Background creation
		    Background bg = new Background(bi);
		 // set background
		    gridPane.setBackground(bg);
	      
	      
	      //Styling nodes  
	      button1.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;"); 
	      button2.setStyle("-fx-background-color: darkslateblue; -fx-text-fill: white;"); 
	      
	      text1.setStyle("-fx-font: normal bold 20px 'serif' "); 
	      text2.setStyle("-fx-font: normal bold 20px 'serif' ");  
	       
	     
	      textField1Validation=textField1.getText().isEmpty();
	      textField2Validation=textField2.getText().isEmpty();
	      
	      button1.setOnAction(new EventHandler<ActionEvent>(){
	    	  //if(ValidateAlert()) {
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  //changeScenes1();
	    		  try
	    		  {
	    			  Class.forName("com.mysql.jdbc.Driver");
	    			  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hitesh","root","");
	    			 
	    			  String u,p;
	    			  u=textField1.getText();
	    			  p=textField2.getText();
	    			  
	    			  Statement st=con.createStatement();
	    			 ResultSet rs= st.executeQuery("select * from account where emailid='"+ u +"' and pass='"+ p +"'");
	    			  if(rs.next())
	    			  {
	    				  //success
	    				  //System.out.println("success");
	    				  changeScenes1();
	    			  	  
	    			  }
	    			  else
	    			  {
	    				  //fail
	    				  //System.out.println("fail");
	    				  JOptionPane.showMessageDialog(null, "Invalid");
	    				  
	    				  
	    			  }
	    			}
	    		  catch(Exception ex) 
	    		  {
	    			  System.out.println("errorrrrr "+ex);
	    			  
	    		  }
	    		  
	    	 }
	    	  
	      });
	
	      button2.setOnAction(new EventHandler<ActionEvent>(){
	    	  @Override
	    	  public void handle(ActionEvent actionEvent) {
	    		  changeScenes2();
	    	  }
	      });
	      

			
	      button2.setOnMouseClicked((new EventHandler<MouseEvent>() { 
	          public void handle(MouseEvent event) { 
	             System.out.println("Email:"+textField1.getText());
	          } 
	       })); 
	      //Creating a scene object 
	      Scene scene = new Scene(gridPane,1000,800); 
	       
	      return scene;
	      
		
	}
	
	
	private static void showAlert(Alert.AlertType alertType, String title, String message) {
		// TODO Auto-generated method stub
		Alert alert=new Alert(alertType);
		alert.setTitle(title);
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.show();
	}
	private void changeScenes1() {
  	  Dashboard dashboard=new Dashboard();
  	  Scene scene=dashboard.getScene();
  	  Startpage.getStage().setScene(scene);
  	 
    }
	private void changeScenes2() {
	  	  Registration registration=new Registration();
	  	  Scene scene=registration.getScene();
	  	  Startpage.getStage().setScene(scene);
	  	  
	    }
	}


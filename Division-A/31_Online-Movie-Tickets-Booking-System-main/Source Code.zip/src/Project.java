import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.animation.ParallelTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Duration;


public class Project extends Application  {
	 static final String JDBC_Driver = "com.mysql.jdbc.Driver";
		static final String DB_URL = "jdbc:mysql://localhost/girrafe";
		static final String USER = "root";
		static final String PASS = "Shiva@2001";     
		public  String[] ID = new String[100];
		public  String[] N= new String[100]; 
		public  String[] E= new String[100]; 
		public  String[] PW= new String[100]; 
		public  String[] PN= new String[100];
	
	
public static void main(String[] args) 
{
	  launch(args);	
}

    public Stage stag; public int count ; public Label tickets_ans;
    public ParallelTransition st; public int c; public int r;
    public int p;/*Payment constants*/
    public String s;public String sText;
    public int n=1;public Stage Payshow;
@Override
public void start(Stage Primarystage) throws Exception {
Text text1 = new Text("Email"); Button back = new Button("Quit");
Text text2 = new Text("Password");
TextField textField1 = new TextField();
PasswordField textField2 = new PasswordField();
this.stag=Primarystage;
Label label1 = new Label("New User?");
Button b1 = new Button("Submit");
Button b2 = new Button("Cancel");
Button b3 = new Button("CLICK HERE to register");
Button b4 = new Button("Admin Login");
Text title = new Text("LOGIN");
title.setUnderline(true); title.setStyle("-fx-font: 40 arial");
DropShadow dropShadow = new DropShadow();
     dropShadow.setBlurType(BlurType.GAUSSIAN);
     dropShadow.setColor(Color.ROSYBROWN);  
     dropShadow.setHeight(10);
     dropShadow.setWidth(6);
     dropShadow.setRadius(5);
     dropShadow.setOffsetX(3);
     dropShadow.setOffsetY(2);      
     dropShadow.setSpread(12);  
     title.setEffect(dropShadow);      
GridPane gp = new GridPane();
gp.setMinSize(400, 200);
gp.setAlignment(Pos.TOP_CENTER);
gp.add(text1, 1, 2);gp.add(back, 0, 0);gp.add(title, 2, 0);
gp.add(textField1, 2, 2);
gp.add(text2, 1, 6);
gp.add(textField2, 2, 6);
gp.add(label1, 1, 10);
gp.add(b3, 2, 10);
gp.add(b4, 4, 0);
gp.setPadding(new Insets(10, 10, 10, 10));
     gp.setVgap(5);
     gp.setHgap(5);      
     gp.setAlignment(Pos.CENTER);
     Image img = new Image("C:\\Users\\RAVI GUPTA\\Downloads\\BackgroundImage.jpg");
       BackgroundImage bImg = new BackgroundImage(img,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundPosition.DEFAULT,
                                                  BackgroundSize.DEFAULT);
       Background bGround = new Background(bImg);
       gp.setBackground(bGround);
     gp.setPrefSize(500, 650);
     final Duration SEC_2 = Duration.millis(1800);  
   TranslateTransition tt = new TranslateTransition(SEC_2);
    tt.setFromX(-10f);
    tt.setToX(100f);
    tt.setCycleCount((int) 2f);
    tt.setAutoReverse(true);
   
   ParallelTransition st = new ParallelTransition(gp, tt);
    st.play();
        st.isAutoReverse();
     text1.setStyle("-fx-font: normal bold 15px 'serif' ");
     text2.setStyle("-fx-font: normal bold 15px 'serif' ");
     label1.setStyle("-fx-font: normal bold 15px 'serif'");
     b2.setStyle( "-fx-background-color: LIGHTBLUE; -fx-textfill: white;");
     b1.setStyle( "-fx-background-color: LIGHTBLUE; -fx-textfill: white;");
     b3.setStyle( "-fx-background-color: BEIGE; -fx-text-fill: #0000ff;");
HBox root = new HBox();
root.getChildren().add(b1);
root.getChildren().add(b2);
root.setSpacing(40);  
Scene scene = new Scene(gp);
gp.add(root,2,9);
Primarystage.setTitle("Login Page ");
Primarystage.setScene(scene);
        Primarystage.show();
       
        b3.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                    RegistrationPage();
                        Primarystage.close();
            }});
        b2.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        Primarystage.close();
        }
        });
        b4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            AdminLogin();
                Primarystage.close();
    }});
        back.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Primarystage.close();
      }});          
        b1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	 if(textField1.getText().isEmpty()) {
                     showAlert1(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter your email id");
                     return;
                 }
                 if(textField2.getText().isEmpty()) {
                     showAlert1(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter a password");
                     return;
                 }
                 else
                 {
                 String emailId = textField1.getText();
         		String password = textField2.getText();
         		
         		JdbcDao jdbcDao = new JdbcDao();
         		boolean flag;
 				try {
 					flag = jdbcDao.validate(emailId, password);
 					if (!flag)
 	        		{
 	        			infoBox("Please enter correct Email and Password", null, "Failed");
 	        		}
 	        		else
 	        		{
 	        			infoBox("Login Successful!",null, "Failed");
 	        			stag.close();
 	        			homePage();
 	        		}
 				} catch (SQLException e) {
 					
 					e.printStackTrace();
 				}
                 }
            }
                 public static void infoBox(String infoMessage, String headerText, String title)
		        	{
		        		Alert alert = new Alert(AlertType.CONFIRMATION);
		        		alert.setContentText(infoMessage);
		        		alert.setTitle(title);
		        		alert.setHeaderText(headerText);
		        		alert.showAndWait();
		        	}
              });
  }
private void showAlert1(Alert.AlertType alertType, Window owner, String title, String message) {
  Alert alert = new Alert(alertType);
  alert.setTitle(title);
  alert.setHeaderText(null);
  alert.setContentText(message);
  alert.initOwner(owner);
  alert.show();
}

{	
Connection conn=null;
try
{
	Class.forName("com.mysql.cj.jdbc.Driver");
	System.out.println("Connecting to a Selected Database");
    conn = DriverManager.getConnection(DB_URL, USER, PASS);
    System.out.println("Connected database Sucessfully");
}
catch(SQLException se)
{
	se.printStackTrace();
}

catch(Exception e)
{
	e.printStackTrace();
}

finally
{
	try
	{
		if(conn!=null)
		conn.close();
	}
	
	catch(SQLException se)
	{
		se.printStackTrace();
	}
}
class connection
{
	
	public static Connection connectDB() throws ClassNotFoundException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con =DriverManager.getConnection(DB_URL,USER,PASS);
			return con;
		}
		catch (SQLException e)
		{
			System.out.println(e);
		}
		return null;
	}
}

Connection con = null;
PreparedStatement p = null;
ResultSet rs = null;

try {
con= connection.connectDB();
} catch (ClassNotFoundException e1) {
// TODO Auto-generated catch block
e1.printStackTrace();
} 
try
{  int c= 0; int a=0; int b=0; int d=0; int e=0; 
   String sql = "Select * from customer";
   p= con.prepareStatement(sql);
   rs =p.executeQuery();
 // System.out.println("Seat_no");
  while (rs.next())
  { 
	 
	  String Customer_id = rs.getString("Customer_id");
	  String Name = rs.getString("Name");
	  String Password= rs.getString("Password");
	  String EmailId = rs.getString("EmailId");
	  String Phone_no = rs.getString("Phone_no");
	 System.out.println("\t\t"+Customer_id + "\t"+Name + "\t"+ Password + "\t" + EmailId + "\t" + Phone_no);
	 N[c++] = Name; PW[a++]=Password; PN[b++]= Phone_no; E[d++]=EmailId;
 	 ID[e++] = Customer_id; 
 	
		}
  
}
catch(SQLException e)
{
   System.out.println(e);
}


}
public void AdminPage() {
	Stage adminstage = new Stage();
	GridPane Agp = new GridPane();
	Label Detail = new Label("CUSTOMER ID");	
	Label l1 = new Label(""+ID[0]);
	Label l2 = new Label(""+ID[1]);
	Label l3 = new Label(""+ID[2]);
	Label l4 = new Label(""+ID[3]);
	Label l5 = new Label(""+ID[4]);
	
	Label Detail1 = new Label("Name");
	Label l6 = new Label(""+N[0]);
	Label l7 = new Label(""+N[1]);
	Label l8 = new Label(""+N[2]);
	Label l9 = new Label(""+N[3]);
	Label l10 = new Label(""+N[4]);
	
	Label Detail2 = new Label("Password");
	Label l11 = new Label(""+PW[0]);
	Label l12= new Label(""+PW[1]);
	Label l13= new Label(""+PW[2]);
	Label l14= new Label(""+PW[3]);
	Label l15 = new Label(""+PW[4]);
	
	Label Detail3 = new Label("Email");
	Label l16 = new Label(""+E[0]);
	Label l17= new Label(""+E[1]);
	Label l18= new Label(""+E[2]);
	Label l19= new Label(""+E[3]);
	Label l20 = new Label(""+E[4]);
	

	Label Detail4 = new Label("Phone no");
	Label l21 = new Label(""+PN[0]);
	Label l22= new Label(""+PN[1]);
	Label l23= new Label(""+PN[2]);
	Label l24= new Label(""+PN[3]);
	Label l25 = new Label(""+PN[4]);
	
	
	Agp.add(l1, 1, 1); Agp.add(l2, 1, 2); Agp.add(l3, 1, 3); Agp.add(l4, 1, 4); Agp.add(l5, 1, 5);
	Agp.add(Detail, 1, 0);
	Agp.add(l6, 2, 1); Agp.add(l7, 2, 2); Agp.add(l8, 2, 3); Agp.add(l9, 2, 4); Agp.add(l10, 2, 5);
	Agp.add(Detail1, 2, 0);
	Agp.add(l11, 3, 1); Agp.add(l12, 3, 2); Agp.add(l13, 3, 3); Agp.add(l14, 3, 4); Agp.add(l15, 3, 5);
	Agp.add(Detail2, 3, 0);
	Agp.setMinSize(400, 200);
	Agp.add(l16, 4, 1); Agp.add(l17, 4, 2); Agp.add(l18,4, 3); Agp.add(l19, 4, 4); Agp.add(l20, 4, 5);
	Agp.add(Detail3, 4, 0);
	Agp.add(l21, 5, 1); Agp.add(l22, 5, 2); Agp.add(l23, 5, 3); Agp.add(l24, 5, 4); Agp.add(l25,5, 5);
	Agp.add(Detail4, 5, 0);
	Agp.setAlignment(Pos.CENTER);
	Agp.setPadding(new Insets(10, 10, 10, 10));
    Agp.setVgap(5);
    Agp.setHgap(5);
	Scene scene = new Scene(Agp);
    adminstage.setTitle("Registration Form");
    adminstage.setScene(scene);  
    adminstage.show();
}

public void AdminLogin(){
Stage adminstage = new Stage();
Text text1 = new Text("ADMIN LOGIN");
    Text AEmail = new Text("Login_id");
    Text APass = new Text("Password");
TextField AEmailField= new TextField();
PasswordField APassField = new PasswordField();
Button B1 = new Button("Submit");
Button B2 = new Button("Cancel");
GridPane Agp = new GridPane();
Agp.setMinSize(400, 200);
Agp.setAlignment(Pos.CENTER);
Agp.add(text1, 1, 1);
Agp.add(AEmail, 0, 3);
Agp.add(APass, 0, 4);
Agp.add(AEmailField, 1, 3);
Agp.add(APassField, 1, 4);
Agp.add(B1, 1, 5);
Agp.add(B2, 2, 5);
Agp.setPadding(new Insets(10, 10, 10, 10));
    Agp.setVgap(5);
    Agp.setHgap(5);
    Agp.setPrefSize(500, 650);
    Scene scene = new Scene(Agp);
    adminstage.setTitle("Registration Form");
    adminstage.setScene(scene);  
    adminstage.show();
   
    Image img = new Image("C:\\Users\\RAVI GUPTA\\Downloads\\BackgroundImage.jpg");
    BackgroundImage bImg = new BackgroundImage(img,
                                               BackgroundRepeat.REPEAT,
                                               BackgroundRepeat.REPEAT,
                                               BackgroundPosition.DEFAULT,
                                               BackgroundSize.DEFAULT);
    Background bGround = new Background(bImg);
    Agp.setBackground(bGround);
    final Duration SEC_2 = Duration.millis(1800);  
    TranslateTransition tt = new TranslateTransition(SEC_2);
     tt.setFromX(100f);
     tt.setToX(20f);
     tt.setCycleCount((int) 1f);
     tt.setAutoReverse(true);
     
     
     ParallelTransition pt = new ParallelTransition(Agp, tt);
     pt.play();
   
    B2.setOnAction(new EventHandler<ActionEvent>() {
    @Override
    public void handle(ActionEvent event) {
    adminstage.close();
    stag.show();
    }
    });
    B1.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        	 if(AEmail.getText().isEmpty()) {
                 showAlert2(Alert.AlertType.ERROR, Agp.getScene().getWindow(), "Form Error!", "Please enter your email id");
                 return;
             }
             if(APass.getText().isEmpty()) {
                 showAlert2(Alert.AlertType.ERROR, Agp.getScene().getWindow(), "Form Error!", "Please enter a password");
                 return;
             }
             else
             {
            String Login_id =AEmail.getText();
     		String Password = APass.getText();
     		
     		JdbcDao jdbcDao = new JdbcDao();
     		boolean flag1;
				try {
					flag1 = jdbcDao.validate1(Login_id, Password);
					if (flag1)
				{
					infoBox("Please enter correct login and Password", null, "Failed");
				}
				else
				{
					infoBox("Login Successful!",null, "Failed");
					stag.close();
					AdminPage();
				}
				} catch (SQLException e) {
 					
 					e.printStackTrace();
 				}
                 }
             }
             public static void infoBox(String infoMessage, String headerText, String title)
	        	{
	        		Alert alert = new Alert(AlertType.CONFIRMATION);
	        		alert.setContentText(infoMessage);
	        		alert.setTitle(title);
	        		alert.setHeaderText(headerText);
	        		alert.showAndWait();
	        	}
             
          });
}
    private void showAlert2(Alert.AlertType alertType, Window owner, String title, String message) {
  	  Alert alert = new Alert(alertType);
  	  alert.setTitle(title);
  	  alert.setHeaderText(null);
  	  alert.setContentText(message);
  	  alert.initOwner(owner);
  	  alert.show();
  	} 
   public void RegistrationPage()  {
       Stage stage = new Stage();
       Text Email = new Text("Email id");
       final TextField emailField = new TextField();
         
       Text passwordLabel = new Text("Password");
       final PasswordField passwordField = new PasswordField();
       
       Text dobLabel = new Text("Date of birth");
       DatePicker datePicker = new DatePicker();
       
       
       Text genderLabel = new Text("gender");      
       ToggleGroup groupGender = new ToggleGroup();
       RadioButton maleRadio = new RadioButton("male");
       maleRadio.setToggleGroup(groupGender);
       RadioButton femaleRadio = new RadioButton("female");
       femaleRadio.setToggleGroup(groupGender);
       
     
     
       Text locationLabel = new Text("location");
       
     
       ChoiceBox locationchoiceBox = new ChoiceBox();
       locationchoiceBox.getItems().addAll
          ("Pune", "Wadoli", "Thane", "Mumbai", "Bandra");
       
       Button buttonRegister = new Button("Register");  
       Button cancel = new Button("Cancel");
        GridPane gridPane = new GridPane();    
//gridPane.setStyle("-fx-background-image: url('https://cdn.app.compendium.com/uploads/user/e7c690e8-6ff9-102a-ac6d-e4aebca50425/ed5569e8-c0dd-458c-8450-cde6300093bd/File/a5023b0f0fb67f59176a0499af9021ed/java_horz_clr.png')");
        Image img = new Image("C:\\Users\\RAVI GUPTA\\Downloads\\BackgroundImage.jpg");
       BackgroundImage bImg = new BackgroundImage(img,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundPosition.DEFAULT,
                                                  BackgroundSize.DEFAULT);
       Background bGround = new Background(bImg);
       gridPane.setBackground(bGround);
       gridPane.setMinSize(500, 500);
       gridPane.setPadding(new Insets(10, 10, 10, 10));  
       gridPane.setVgap(5);
       gridPane.setHgap(5);      
       gridPane.setAlignment(Pos.CENTER);
       gridPane.add(cancel,2,6);
       gridPane.add(Email, 0, 0);
       gridPane.add(emailField, 1, 0);        
       gridPane.add(passwordLabel, 0, 1);
       gridPane.add(passwordField, 1, 1);
       gridPane.add(dobLabel, 0, 2);      
       gridPane.add(datePicker, 1, 2);
       gridPane.add(genderLabel, 0, 3);
       gridPane.add(maleRadio, 1, 3);      
       gridPane.add(femaleRadio, 2, 3);
       gridPane.add(locationLabel, 0, 4);
       gridPane.add(locationchoiceBox, 1, 4);      
       gridPane.add(buttonRegister, 0, 6);
       gridPane.setPrefSize(500, 650);
       final Duration SEC_2 = Duration.millis(1800);  
       TranslateTransition tt = new TranslateTransition(SEC_2);
        tt.setFromX(100f);
        tt.setToX(30f);
        tt.setCycleCount((int) 1f);
        tt.setAutoReverse(true);
       
        ParallelTransition pt = new ParallelTransition(gridPane, tt);
        pt.play();
        pt.isAutoReverse();
         
       buttonRegister.setStyle(
          "-fx-background-color: LIGHTBLUE; -fx-textfill: white;");        
       Email.setStyle("-fx-font: normal bold 15px 'serif' ");
       passwordLabel.setStyle("-fx-font: normal bold 15px 'serif' ");
       dobLabel.setStyle("-fx-font: normal bold 15px 'serif' ");
       genderLabel.setStyle("-fx-font: normal bold 15px 'serif' ");      
       locationLabel.setStyle("-fx-font: normal bold 15px 'serif' ");          
       //gridPane.setStyle("-fx-background-color: BEIGE;");      
               
       Scene scene = new Scene(gridPane);                
       stage.setTitle("Registration Form");      
       stage.setScene(scene);
       stage.show();
     
       cancel.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        stage.close();
        stag.show();
        }
       });  
       
       
    buttonRegister.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
           
            if(emailField.getText().isEmpty()) {
                showAlert1(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!", "Please enter your email id");
                return;
            }
            if(passwordField.getText().isEmpty()) {
                showAlert1(Alert.AlertType.ERROR, gridPane.getScene().getWindow(), "Form Error!", "Please enter a password");
                return;
            }else {
            showAlert1(Alert.AlertType.CONFIRMATION, gridPane.getScene().getWindow(), "Registration Successful!", "Welcome " + emailField.getText());
            stag.show();
             stage.close();
            }
           
           
        }});
    }
   
    private void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.initOwner(owner);
    alert.show();
   
    }
    public void homePage(){
   
    final String BatM= "Batman"; final String BatD="In his second year of fighting crime, Batman uncovers corruption in Gotham City that connects to\n his own family while facing a serial killer known as the Riddler.The Batman is an upcoming American superhero film based on the DC Comics character Batman. Produced by DC Films,\n 6th & Idaho, and Dylan Clark Productions, and set for distribution by Warner Bros. Pictures, it is a reboot of the Batman film franchise. ";
final String SoorD = " Sooryavanshi is an upcoming Indian Hindi-language action film directed by Rohit Shetty\n"+" and produced by Reliance Entertainment, Rohit Shetty Picturez, \nDharma Productions and Cape of Good Films, based on a script by Yunus Sajawal\n, Farhad Samji, Sanchit Bendre and Vidhi Ghodgadnkar and an original story by Shetty.\n           ";
final String PushM= "Pushpa"; final String SanM= "Sanak";final  String SuperM="Superman";
final String PushD="Pushpa: The Rise � Part 1 is an upcoming Indian Telugu-language action thriller film written and directed by Sukumar.\n Produced by Naveen Yerneni and Y. Ravi Shankar of Mythri Movie Makers in association with Muttamsetty Media,\n the film stars Allu Arjun as the title character alongside Fahadh Faasil (in his Telugu debut) and Rashmika Mandanna.\n The first of two cinematic parts, the plot is based on the red sanders smuggling in the Seshachalam Hills of the Rayalaseema region of Andhra Pradesh.";
final  String SanD="Vivaan, an MMA trainer admits his wife Anshika in a hospital subsequently a terrorist gang infiltrate \ninto the hospital to bring Ajay Pal Singh, kingpin of Arms dealer. Anshika and others became entrapped in a hostage situation.\n Vivaan enters in the hospital with the help of a guard and kills single-handedly all the terrorist before the commandos enters.\r\n";
final String SuperD="An alien orphan is sent from his dying planet to Earth, where he grows up to become his\n adoptive home's first and greatest superhero.Superman (stylized as Superman: The Movie) is a 1978 superhero film\n directed by Richard Donner, supervised by Alexander and Ilya Salkind, produced by their partner Pierre Spengler, \nwritten by Mario Puzo, David Newman, Leslie Newman, and Robert Benton from a story by Puzo based on the DC Comics character of the same name";
         
Font font = Font.font("Verdana", FontWeight.EXTRA_BOLD, 12.5);
final Text home = new Text("HOME");  
home.setFont(Font.font ("Verdana", 20));
home.setFill(Color.DARKBLUE);
final Image image = new Image("C:\\Users\\RAVI GUPTA\\OneDrive\\Desktop\\New folder\\Important\\Superman.jpg");
ImageView imageView = new ImageView(); String T5 = ("C:\\Users\\RAVI GUPTA\\Downloads\\Meldar-SupermanReturnsTrailer293.mp4");
imageView.setImage(image);
imageView.setX(10);
imageView.setY(10);
imageView.setFitWidth(210);
imageView.setFitHeight(240);
imageView.setPreserveRatio(true);
Button superman = new Button();
superman.setGraphic(imageView);  superman.setStyle("-fx-background-color: MIDNIGHTBLUE");
Button DS = new Button("SUPERMAN "+ "\nDirected by: Richard Donner \r\n"+"Produced by: Charles Greenlaw \r\n"+"Stars : Christopher Reeve \r\n"+"Valerie Perrine\r\n\r\n\r\n\r\n\r\n");
DS.setStyle("-fx-background-color: MIDNIGHTBLUE; -fx-text-fill: white;");
DS.setFont(font);
   DS.setPrefSize(310,250);
   
    final String SoorM = ("Sooryavanashi");
final Image BATMAN = new Image("C:\\Users\\RAVI GUPTA\\OneDrive\\Desktop\\New folder\\Important\\Batman.jpg");
ImageView bat = new ImageView(); String T3 =("C:\\Users\\RAVI GUPTA\\Downloads\\BATMAN 1989 trailer.mp4");
bat.setImage(BATMAN);
bat.setX(10);
bat.setY(10);
bat.setFitWidth(370);
bat.setFitHeight(240);
bat.setPreserveRatio(true);
Button batman= new Button();
batman.setGraphic(bat); batman.setStyle("-fx-background-color: MIDNIGHTBLUE");
Button BB = new Button("BATMAN\r\n"+"Director :\r\n"
+ "Matt Reeves\r\n"
+ "\r\nWriters :\r\n"
+ "Matt Reeves\nPeter Craig\nBob Kane(Batman created by)\r\n"
+ "\r\nStars :\r\n"
+ "Peter Sarsgaard\nAndy Serkis\nRobert Pattinson\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\r\n");
BB.setFont(font); BB.setStyle("-fx-background-color: MIDNIGHTBLUE; -fx-text-fill: white;");
      BB.setPrefSize(310,250);

final Image SANAK = new Image("C:\\Users\\RAVI GUPTA\\OneDrive\\Desktop\\New folder\\Important\\Sanak.jpg");
ImageView sk = new ImageView(); String T4 =( "C:\\Users\\RAVI GUPTA\\Downloads\\Sanak 2021 Official Trailer Ft. Vidyut Jammwal_HD-(Hd9video).mp4");
sk.setImage(SANAK);
sk.setX(10);
sk.setY(10);
sk.setFitWidth(170);
sk.setFitHeight(250);
sk.setPreserveRatio(true);
       Button sanak= new Button();
       sanak.setGraphic(sk); sanak.setStyle("-fx-background-color: MIDNIGHTBLUE");
       Button BK = new Button("Director\r\n"
        + "Kanishk Varma\r\n"
        + "Writer\r\n"
        + "Ashish P. Verma\r\n"
        + "Stars\r\n"
        + "Vidyut Jammwal\nRukmini Maitra\nNeha Dhupia");
       BK.setFont(font);        BK.setTextAlignment(TextAlignment.LEFT);
      BK.setPrefSize(300,250); BK.setStyle("-fx-background-color: MIDNIGHTBLUE; -fx-text-fill: white;");

final Image PUSHPA = new Image("C:\\Users\\RAVI GUPTA\\OneDrive\\Desktop\\New folder\\Important\\pushpa.jpg");
ImageView imagevi = new ImageView(PUSHPA); String T2 = "C:\\Users\\RAVI GUPTA\\Downloads\\Pushpa-Trailer-Full-Screen-Pushpa-Raj-Trailer-Status-Allu-Arjun-Birthday-Special.mp4";
imagevi.setFitWidth(305);
imagevi.setFitHeight(240);
imagevi.setPreserveRatio(true);
Button pushpa= new Button();
pushpa.setGraphic(imagevi);
pushpa.setPrefSize(80, 80); pushpa.setStyle("-fx-background-color: MIDNIGHTBLUE");
Button BP = new Button("Director :\r\n"
+ "Sukumar\r\n"
+ "\r\nWriters :\r\n"
+ "Sukumar(story) (screenplay)\nSrikanth Vissa(dialogue)"
+"\r\nStars :"+"\nAllu Arjun");
       BP.setFont(font);        BP.setTextAlignment(TextAlignment.LEFT);
      BP.setPrefSize(310,250); BP.setStyle("-fx-background-color: MIDNIGHTBLUE; -fx-text-fill: white;");    
       
       final Image img = new Image("C:\\Users\\RAVI GUPTA\\OneDrive\\Desktop\\New folder\\Important\\Sooryavanshi.jpg");
       final ImageView view = new ImageView(img); String T1 = "C:\\Users\\RAVI GUPTA\\Downloads\\Sooryavanshi Trailer Full HD (1).mp4";
       view.setFitWidth(290);
       view.setFitHeight(240);
       view.setPreserveRatio(true);
       Button button = new Button();
       button.setPrefSize(80, 80);
       button.setGraphic(view); button.setStyle("-fx-background-color: MIDNIGHTBLUE");
       final Button BS = new Button("Director:\r\n"
        + "Rohit Shetty\r\n"
        + "\r\nWriters: \r\n"
        + "Sanchit Bedre(dialogue)\n Vidhi Ghodgaonkar(dialogue)\n Yunus Sajawal(screenplay)\r\n"
        + "\r\nStars: \r\n"
        + "Akshay Kumar \nKatrina Kaif\nAjay Devgn\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n");
       BS.setPrefSize(300,250);
       BS.setFont(font); BS.setStyle("-fx-background-color:MIDNIGHTBLUE; -fx-text-fill: white;");
       BS.setTextAlignment(TextAlignment.LEFT);
       
       Button search = new Button("Search");
       final TextField searchfield = new TextField();
       HBox hbox = new HBox(home,search,searchfield);
       hbox.setSpacing(50); hbox.setAlignment(Pos.CENTER);
   GridPane gp = new GridPane();
   HBox H1 = new HBox(button,BS);  HBox H2 = new HBox(pushpa,BP); HBox H3 = new HBox(batman,BB);
   HBox H4 = new HBox(sanak, BK); gp.add(H4, 1, 4); HBox H5 = new HBox(superman,DS);
   gp.add(hbox, 1, 0); gp.add(H1, 1, 1); gp.add(H2, 1, 2); gp.add(H3, 1, 3); gp.add(H5,1,5);
       gp.setAlignment(Pos.CENTER);
//gp.setStyle("-fx-background-color: cadetblue;");
   gp.setPadding(new Insets(1, 1, 1, 1));
   gp.setVgap(5);
   gp.setHgap(1);
       gp.setPrefSize(1500, 1000);
       Stage stage = new Stage();  
       search.setPrefSize(80,30); searchfield.setPrefSize(200,30);
     ScrollPane scrollPane = new ScrollPane();
       scrollPane.setContent(gp);
       scrollPane.setPannable(true);        
       
       Image back = new Image("C:\\Users\\RAVI GUPTA\\Downloads\\BackgroundImage.jpg");
       BackgroundImage bImg = new BackgroundImage(back,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundPosition.DEFAULT,
                                                  BackgroundSize.DEFAULT);
       Background bGround = new Background(bImg);
       gp.setBackground(bGround);
       search.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        try {
           String s = searchfield.getText();              
           stage.close();  
        s.trim();        
        char ch=' ';
        s.toLowerCase();
           char[] charArray = s.toCharArray();        
               ch = charArray[0];
               
       switch(ch)
       {
       case 's':  result(SoorM,SoorD,SanM,SanD,SuperM,SuperD);                  
       break;
       case 'b' : result(BatM,BatD);
       break;
       case 'p' : result(PushM,PushD);
       break;        
       } }
       catch(Exception e) {
       searchfield.setPromptText("No Results!!");
       }
        }
        public void result(String m , String d,String sanm, String sand,String supm,String supd) {
        GridPane gp = new GridPane();
        gp.add(home, 1, 0);
               gp.setAlignment(Pos.TOP_CENTER);
               gp.setVgap(5);
           gp.setHgap(5);
               gp.setPrefSize(500, 650);
               Button B = new Button(" "+m+"\n"+d);
               Button A = new Button(""+sanm+"\n"+sand);
               Button D = new Button(""+supm+"\n"+supd);
               Button back = new Button("< Back");
               gp.add(B, 0, 2);
               gp.add(A, 0, 3);
               gp.add(D, 0, 4);
               gp.add(back, 0, 0);
               Scene scene = new Scene(gp);        
        stage.setTitle("Home Page ");
        stage.setScene(scene);
        stage.show();
               back.setPrefSize(120,30);
               back.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            stage.show();  
            homePage();
            }
           });
        B.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            stage.close();  
            Description(SoorM,SoorD,img,T1);
            }
           });
        A.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            stage.close();  
            Description(SanM,SanD,SANAK,T4);
            }
           });
           D.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            stage.close();  
            Description(SuperM,SuperD,image,T5);
            }
           });
        }
        public void result(final String m , final String d) {
        GridPane gp = new GridPane();
        gp.add(home, 2, 0);
               gp.setAlignment(Pos.TOP_CENTER);
               gp.setVgap(5);
           gp.setHgap(5);
               gp.setPrefSize(500, 650);
               Button B = new Button(" "+m+"\n"+d);
               gp.add(B, 0, 2);
                   Scene scene = new Scene(gp);
        stage.setTitle("Home Page ");
        stage.setScene(scene);
        stage.show();
        B.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            stage.close();
            Description(m,d,PUSHPA,T2);
            }
           });
       }}); //  all_btn[75].setOnAction(e->setDisplay(all_btn[75],75));
       button.setOnAction(event -> {stage.close(); Description(SoorM,SoorD,img,T1);});
       pushpa.setOnAction(event -> {stage.close(); Description(SoorM,SoorD,img,T1);});
       sanak.setOnAction(event -> {stage.close(); Description(SoorM,SoorD,img,T1);});
       batman.setOnAction(event -> {stage.close(); Description(SoorM,SoorD,img,T1);});
       superman.setOnAction(event -> {stage.close(); Description(SoorM,SoorD,img,T1);});
       BS.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        stage.close();  
        Description(SoorM,SoorD,img,T1);
        }
       });
       BB.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        stage.close();  
        Description(BatM,BatD,BATMAN,T3);
        }
       });
       BK.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        stage.close();  
        Description(SanM,SanD,SANAK,T4);
        }
       });
       DS.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        stage.close();  
        Description(SuperM,SuperD,image,T5);
        }
       });
       BP.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        stage.close();  
        Description(PushM,PushD,PUSHPA,T2);
        }
       });

Scene scene = new Scene(scrollPane,500,500);

stage.setTitle("Home Page ");
stage.setScene(scene);
stage.show();

final Duration SEC_2 = Duration.millis(1800);

   
   TranslateTransition tt = new TranslateTransition(SEC_2);
    tt.setFromX(100f);
    tt.setToX(-10f);
    tt.setCycleCount((int) 1f);
    tt.setAutoReverse(true);
    ParallelTransition pt = new ParallelTransition(gp, tt);
    pt.play();
}



public void Description(String name,String desc,Image image,String path){
       ImageView view = new ImageView(image);//C:\Users\Admin\Downloads
       Media media = new Media(new File(path).toURI().toString());  
       MediaPlayer mediaPlayer = new MediaPlayer(media);
       mediaPlayer.setAutoPlay(true);
       MediaView mediaView = new MediaView(mediaPlayer);    
         mediaPlayer.play();
       mediaPlayer.setAutoPlay(true);
      // root.getChildren().add(mediaView);
       mediaPlayer.setMute(true);
       view.setFitWidth(1000);  
       view.setFitHeight(400);
       view.setX(10);
view.setY(10);
       view.setPreserveRatio(true);
       Text s1 = new Text(desc);
       Label l1 = new Label(name); l1.setStyle("-fx-font: 40 arial"); l1.setUnderline(true);
       Button sb = new Button("BOOK TICKETS");
       Button back = new Button("< Back"); back.setPrefSize(20,80);
       final Stage moviestage = new Stage();
       GridPane gp = new GridPane();
gp.setAlignment(Pos.CENTER);
gp.add(mediaView,1,1);
gp.add(s1, 1 , 3);
gp.add(l1,1 , 2);
gp.add(sb,1 , 4);
gp.add(back, 1, 0);back.setPrefSize(50,30);
gp.setPadding(new Insets(10, 10, 10, 10));
   gp.setVgap(5);
   gp.setHgap(5);
       gp.setPrefSize(500 , 650);
       ScrollPane scrollPane = new ScrollPane();
       scrollPane.setContent(gp);
       scrollPane.setPannable(true);
   Scene scene = new Scene(scrollPane,500,500);
       moviestage.setTitle("Description");
       moviestage.setScene(scene);  
       moviestage.show();
       Image img = new Image("C:\\Users\\RAVI GUPTA\\Downloads\\BackgroundImage.jpg");
       BackgroundImage bImg = new BackgroundImage(img,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundPosition.DEFAULT,
                                                  BackgroundSize.DEFAULT);
       Background bGround = new Background(bImg);
       gp.setBackground(bGround);
final Duration SEC_2 = Duration.millis(1800);    
   TranslateTransition tt = new TranslateTransition(SEC_2);
    tt.setFromX(100f);
    tt.setToX(-10f);
    tt.setCycleCount((int) 1f);
    tt.setAutoReverse(true);
    ParallelTransition pt = new ParallelTransition(gp, tt);
    pt.play();
       back.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        moviestage.close();
        mediaPlayer.setMute(true);
        homePage();
        }
       });    
       sb.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        moviestage.close();  
        mediaPlayer.setMute(true);
        PaymentPage();
        }
       });    
}
public void PaymentPage(){
Stage stage = new Stage();
final TextField Tick = new TextField();
this.Payshow = stage;
Label theatre = new Label("Choose the theatre:");
final ChoiceBox cinemachoiceBox = new ChoiceBox();
cinemachoiceBox.getItems().addAll
   ("Mayur Cinema- Subhash lane Bhagat colony kandivali west", "Carnival Cinema - Annex mall Borivali East", "PVR ICON - Oberoi Mall Western Express Highway", "Cinemax - Infinitay Mall New Link Road Malad");
Label Lang= new Label("Choose the Language:");
ChoiceBox langchoice = new ChoiceBox();
langchoice.getItems().addAll("English","Hindi","Tamil");
Label Format = new Label("Choose the format:");
ChoiceBox formatchoice = new ChoiceBox();
formatchoice.getItems().addAll("2D","3D","MX4D","IMAX 3D");
Label date = new Label("Choose the date:");
DatePicker moviedatePicker = new DatePicker();
ToggleGroup groupGender = new ToggleGroup();
     RadioButton maleRadio = new RadioButton("male");
Button Book = new Button("Book Tickets");
   Button Select = new Button("SELECT SEAT");

final Label response = new Label("");
     // Create the radio buttons.
     final RadioButton rbCard = new RadioButton("Card");
     final RadioButton rbApp = new RadioButton("Google Pay , PayTM ,PhonePe");
     final RadioButton rbUpi = new RadioButton("UPI");
     // Create a toggle group.
     ToggleGroup tg = new ToggleGroup();
     // Add each button to a toggle group.
     rbCard.setToggleGroup(tg);
     rbApp.setToggleGroup(tg);
     rbUpi.setToggleGroup(tg);

  // Use a change listener to respond to a change of selection within
  // the group of radio buttons.
     tg.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
     public void changed(ObservableValue<? extends Toggle> changed,
                 Toggle oldVal, Toggle newVal) {
      // Cast new to RadioButton.
      RadioButton rb = (RadioButton) newVal;
      // Display the selection.
      response.setText("Payment Mode selected is " + rb.getText());
     
    }
   });

  rbCard.setSelected(true);
     rbCard.fire();
     FlowPane rootNode = new FlowPane(10, 10);
     rootNode.setAlignment(Pos.CENTER);
     rootNode.getChildren().addAll(rbCard, rbApp, rbUpi, response);
   

 
GridPane gp = new GridPane();
gp.setAlignment(Pos.CENTER);
gp.add(theatre, 0, 1);
gp.add(Lang, 0, 2);   gp.add(rootNode, 0, 8);
gp.add(Format, 0, 3);
gp.add(date, 0, 4); gp.add(Book, 0, 9);
   gp.add(Select, 1, 9);
gp.add(cinemachoiceBox, 1, 1);
gp.add(moviedatePicker, 1, 4);
gp.add(formatchoice, 1, 3);
gp.add(langchoice, 1, 2);
gp.setPadding(new Insets(10, 10, 10, 10));
   gp.setVgap(5);
   gp.setHgap(5);
   gp.setPrefSize(500, 650);
   Image img = new Image("C:\\Users\\RAVI GUPTA\\Downloads\\BackgroundImage.jpg");
       BackgroundImage bImg = new BackgroundImage(img,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundRepeat.REPEAT,
                                                  BackgroundPosition.DEFAULT,
                                                  BackgroundSize.DEFAULT);
       Background bGround = new Background(bImg);
       gp.setBackground(bGround);
  Scene scene = new Scene(gp);
stage.setTitle(" ");
stage.setScene(scene);
       stage.show();
       final Duration SEC_2 = Duration.millis(1800);    
   TranslateTransition tt = new TranslateTransition(SEC_2);
    tt.setFromX(100f);
    tt.setToX(-10f);
    tt.setCycleCount((int) 1f);
    tt.setAutoReverse(true);
    ParallelTransition pt = new ParallelTransition(gp, tt);
    pt.play();
    Select.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent event) {
            set cons = new set();
            cons.seat2();
           }});
       Book.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent event) {
            set pay = new set();                  
            if(rbCard.isSelected()) {
                    pay.CardPage();}
            if(rbApp.isSelected()) {
                  pay.AppPage();}
            if(rbUpi.isSelected()) {
                  pay.UPI();}}
            //catch(Exception cal) {            
               //   showAlert1(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter a Valid Number in 'No. of Tickets'");
   });
       
}
 
  public class set{
     
      Label title;
         Label screen,one,two,three,four,five,six,seven,eight,nine,ten;
      Label f1;
Label f2;
         Label movie,time,tickets,total,seats,movie_ans,time_ans,total_ans,seats_ans,available,sold,selected;
         Button book,b_available,b_sold,b_selected;

         Button r1c1,r1c2,r1c3,r1c4,r1c5,r1c6,r1c7,r1c8,r1c9,r1c10;
         Button r2c1,r2c2,r2c3,r2c4,r2c5,r2c6,r2c7,r2c8,r2c9,r2c10;
         Button r4c1,r4c2,r4c3,r4c4,r4c5,r4c6,r4c7,r4c8;
         Button r5c1,r5c2,r5c3,r5c4,r5c5,r5c6,r5c7,r5c8,r5c9,r5c10;
         Button r6c1,r6c2,r6c3,r6c4,r6c5,r6c6,r6c7,r6c8,r6c9,r6c10;
         Button r7c1,r7c2,r7c3,r7c4,r7c5,r7c6,r7c7,r7c8,r7c9,r7c10;
         Button r8c1,r8c2,r8c3,r8c4,r8c5,r8c6,r8c7,r8c8,r8c9,r8c10;
         Button r9c1,r9c2,r9c3,r9c4,r9c5,r9c6,r9c7,r9c8,r9c9,r9c10;
         Button r10c3,r10c4,r10c5,r10c6,r10c7,r10c8;

         String grey = "-fx-background-color:#B2BEB5";
         String green = "-fx-background-color:#32CD32";

         String[] btn = {"r1c1","r1c2","r1c3","r1c4","r1c5","r1c6","r1c7","r1c8","r1c9","r1c10","r2c1","r2c2","r2c3","r2c4","r2c5","r2c6","r2c7","r2c8","r2c9","r2c10","r4c1","r4c2","r4c3","r4c4","r4c5","r4c6","r4c7","r4c8","r5c1","r5c2","r5c3","r5c4","r5c5","r5c6","r5c7","r5c8","r5c9","r5c10","r6c1","r6c2","r6c3","r6c4","r6c5","r6c6","r6c7","r6c8","r6c9","r6c10","r7c1","r7c2","r7c3","r7c4","r7c5","r7c6","r7c7","r7c8","r7c9","r7c10","r8c1","r8c2","r8c3","r8c4","r8c5","r8c6","r8c7","r8c8","r8c9","r8c10","r9c1","r9c2","r9c3","r9c4","r9c5","r9c6","r9c7","r9c8","r9c9","r9c10","r10c3","r10c4","r10c5","r10c6","r10c7","r10c8"};
         String[] btn_clr = {grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey,grey};
         Button[] all_btn = {r1c1,r1c2,r1c3,r1c4,r1c5,r1c6,r1c7,r1c8,r1c9,r1c10,r2c1,r2c2,r2c3,r2c4,r2c5,r2c6,r2c7,r2c8,r2c9,r2c10,r4c1,r4c2,r4c3,r4c4,r4c5,r4c6,r4c7,r4c8,r5c1,r5c2,r5c3,r5c4,r5c5,r5c6,r5c7,r5c8,r5c9,r5c10,r6c1,r6c2,r6c3,r6c4,r6c5,r6c6,r6c7,r6c8,r6c9,r6c10,r7c1,r7c2,r7c3,r7c4,r7c5,r7c6,r7c7,r7c8,r7c9,r7c10,r8c1,r8c2,r8c3,r8c4,r8c5,r8c6,r8c7,r8c8,r8c9,r8c10,r9c1,r9c2,r9c3,r9c4,r9c5,r9c6,r9c7,r9c8,r9c9,r9c10,r10c3,r10c4,r10c5,r10c6,r10c7,r10c8};
         Button[] selected_btn = new Button[84];

         String seats_val = "";
          int ticket = 0;
         int amount = 0;
         int count = 0;
           int booked[]= new int[84];
         String clr;
         
         public void setDisplay(Button b , int indx){
             clr = btn_clr[indx];
           
             if(clr==grey){
                 b.setStyle(green);
                 btn_clr[indx] = green;
                 ticket++;
                 if(indx<78){
                     amount+=120;
                     total_ans.setText(": Rupees "+amount);
                 }
               
                 else{
                     amount+=200;
                     total_ans.setText(": Rupees "+amount);
                 }
                 tickets_ans.setText(": "+ticket);
                 selected_btn[indx] = b;
                 seats_val = ": ";
                 for(int i=0;i<84;i++){
                     if(selected_btn[i]!=null){
                         seats_val+=(btn[i]+" ");
                     }
                 }
                 seats_ans.setText(seats_val);
                 c = ticket; r = amount;
             }
             //if button color is green, go to this statement
             //this statement used to remove order
             else if(clr==green){
                 b.setStyle(grey);
                 btn_clr[indx] = grey;
                 ticket--;
                 if(indx<78){
                     amount-=12;
                     total_ans.setText(": Rupees "+amount);
                 }
                 //in last row seat should 20 $
                 else{
                     amount-=20;
                     total_ans.setText(": Rupees "+amount);
                 }
                 tickets_ans.setText(": "+ticket);
                 selected_btn[indx] = null;
                 seats_val = ": ";
                 for(int i=0;i<84;i++){
                     if(selected_btn[i]!=null){
                         seats_val+=(btn[i]+" ");
                     }
                 }
                 seats_ans.setText(seats_val);
             }
             for(int i=0;i<84;i++){
                 if(btn_clr[i] !=grey) {
                 booked[i] = indx; 
                 }}
         }

         public void seat2() {
       
             Stage stage = new Stage();
             title = new Label("Multiplex Theatre Showing Screen1");
             title.setPrefSize(500,80);
             title.setAlignment(Pos.CENTER);
             title.setFont(new Font("Lucida Sans Unicode",25));

             screen = new Label("SCREEN");
             screen.setStyle("-fx-background-color: #FFA500");
             screen.setPrefSize(348,35);
             screen.setAlignment(Pos.CENTER);
             screen.setFont(new Font("Verdana",15));
             screen.setTextFill(Color.rgb(255,255,255));
             f1 = new Label("");
             f1.setPrefSize(15,35);

             int[] label_btn = {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,3,4,5,6,7,8};

             for(int i = 0; i<84; i++){
                 all_btn[i] = new Button(label_btn[i]+"");
                 all_btn[i].setPrefSize(30,35);
                 all_btn[i].setStyle(grey);
                 all_btn[i].setTextFill(Color.rgb(255,255,255));
             }

             one = new Label("1");
             one.setPrefSize(15,35);

             two = new Label("2");
             two.setPrefSize(15,35);

             three = new Label("3");
             three.setPrefSize(10,15);

             four = new Label("4");
             four.setPrefSize(15,35);

             five = new Label("5");
             five.setPrefSize(15,35);

             six = new Label("6");
             six.setPrefSize(15,35);

             seven = new Label("7");
             seven.setPrefSize(15,35);

             eight = new Label("8");
             eight.setPrefSize(15,35);

             nine = new Label("9");
             nine.setPrefSize(15,35);

             ten = new Label("10");
             ten.setPrefSize(15,35);
             f2 = new Label(" ");
             f2.setPrefSize(65,35);

             HBox hb1 = new HBox();
             HBox hb2 = new HBox();
             HBox hb3 = new HBox();
             HBox hb4 = new HBox();
             HBox hb5 = new HBox();
             HBox hb6 = new HBox();
             HBox hb7 = new HBox();
             HBox hb8 = new HBox();
             HBox hb9 = new HBox();
             HBox hb10 = new HBox();

             hb1.getChildren().addAll(one,all_btn[0],all_btn[1],all_btn[2],all_btn[3],all_btn[4],all_btn[5],all_btn[6],all_btn[7],all_btn[8],all_btn[9]);
             hb1.setSpacing(5);
             hb1.setPadding(new Insets(5,5,5,20));

             hb2.getChildren().addAll(two,all_btn[10],all_btn[11],all_btn[12],all_btn[13],all_btn[14],all_btn[15],all_btn[16],all_btn[17],all_btn[18],all_btn[19]);
             hb2.setSpacing(5);
             hb2.setPadding(new Insets(5,5,5,20));

             hb3.getChildren().add(three);
             hb3.setSpacing(5);
             hb3.setPadding(new Insets(5,45,5,20));

             hb4.getChildren().addAll(four,all_btn[20],all_btn[21],all_btn[22],all_btn[23],all_btn[24],all_btn[25],all_btn[26],all_btn[27]);
             hb4.setSpacing(5);
             hb4.setPadding(new Insets(5,45,5,20));

             hb5.getChildren().addAll(five,all_btn[28],all_btn[29],all_btn[30],all_btn[31],all_btn[32],all_btn[33],all_btn[34],all_btn[35],all_btn[36],all_btn[37]);
             hb5.setSpacing(5);
             hb5.setPadding(new Insets(5,45,5,20));

             hb6.getChildren().addAll(six,all_btn[38],all_btn[39],all_btn[40],all_btn[41],all_btn[42],all_btn[43],all_btn[44],all_btn[45],all_btn[46],all_btn[47]);
             hb6.setSpacing(5);
             hb6.setPadding(new Insets(5,45,5,20));

             hb7.getChildren().addAll(seven,all_btn[48],all_btn[49],all_btn[50],all_btn[51],all_btn[52],all_btn[53],all_btn[54],all_btn[55],all_btn[56],all_btn[57]);
             hb7.setSpacing(5);
             hb7.setPadding(new Insets(5,45,5,20));

             hb8.getChildren().addAll(eight,all_btn[58],all_btn[59],all_btn[60],all_btn[61],all_btn[62],all_btn[63],all_btn[64],all_btn[65],all_btn[66],all_btn[67]);
             hb8.setSpacing(5);
             hb8.setPadding(new Insets(5,45,5,20));

             hb9.getChildren().addAll(nine,all_btn[68],all_btn[69],all_btn[70],all_btn[71],all_btn[72],all_btn[73],all_btn[74],all_btn[75],all_btn[76],all_btn[77]);
             hb9.setSpacing(5);
             hb9.setPadding(new Insets(5,45,5,20));

             hb10.getChildren().addAll(ten,f2,all_btn[78],all_btn[79],all_btn[80],all_btn[81],all_btn[82],all_btn[83]);
             hb10.setSpacing(5);
             hb10.setPadding(new Insets(5,45,5,20));

             HBox scn = new HBox();
             scn.getChildren().addAll(f1,screen);
             scn.setSpacing(5);
             scn.setPadding(new Insets(5,10,20,20));

             VBox vb1 = new VBox();
             vb1.setAlignment(Pos.TOP_CENTER);
             vb1.setMinSize(430,0);
             vb1.getChildren().addAll(scn,hb1,hb2,hb3,hb4,hb5,hb6,hb7,hb8,hb9,hb10);

             all_btn[0].setOnAction(e->setDisplay(all_btn[0],0));
             all_btn[1].setOnAction(e->setDisplay(all_btn[1],1));
             all_btn[2].setOnAction(e->setDisplay(all_btn[2],2));
             all_btn[3].setOnAction(e->setDisplay(all_btn[3],3));
             all_btn[4].setOnAction(e->setDisplay(all_btn[4],4));
             all_btn[5].setOnAction(e->setDisplay(all_btn[5],5));
             all_btn[6].setOnAction(e->setDisplay(all_btn[6],6));
             all_btn[7].setOnAction(e->setDisplay(all_btn[7],7));
             all_btn[8].setOnAction(e->setDisplay(all_btn[8],8));
             all_btn[9].setOnAction(e->setDisplay(all_btn[9],9));
             all_btn[10].setOnAction(e->setDisplay(all_btn[10],10));
             all_btn[11].setOnAction(e->setDisplay(all_btn[11],11));
             all_btn[12].setOnAction(e->setDisplay(all_btn[12],12));
             all_btn[13].setOnAction(e->setDisplay(all_btn[13],13));
             all_btn[14].setOnAction(e->setDisplay(all_btn[14],14));
             all_btn[15].setOnAction(e->setDisplay(all_btn[15],15));
             all_btn[16].setOnAction(e->setDisplay(all_btn[16],16));
             all_btn[17].setOnAction(e->setDisplay(all_btn[17],17));
             all_btn[18].setOnAction(e->setDisplay(all_btn[18],18));
             all_btn[19].setOnAction(e->setDisplay(all_btn[19],19));
             all_btn[20].setOnAction(e->setDisplay(all_btn[20],20));
             all_btn[21].setOnAction(e->setDisplay(all_btn[21],21));
             all_btn[22].setOnAction(e->setDisplay(all_btn[22],22));
             all_btn[23].setOnAction(e->setDisplay(all_btn[23],23));
             all_btn[24].setOnAction(e->setDisplay(all_btn[24],24));
             all_btn[25].setOnAction(e->setDisplay(all_btn[25],25));
             all_btn[26].setOnAction(e->setDisplay(all_btn[26],26));
             all_btn[27].setOnAction(e->setDisplay(all_btn[27],27));
             all_btn[28].setOnAction(e->setDisplay(all_btn[28],28));
             all_btn[29].setOnAction(e->setDisplay(all_btn[29],29));
             all_btn[30].setOnAction(e->setDisplay(all_btn[30],30));
             all_btn[31].setOnAction(e->setDisplay(all_btn[31],31));
             all_btn[32].setOnAction(e->setDisplay(all_btn[32],32));
             all_btn[33].setOnAction(e->setDisplay(all_btn[33],33));
             all_btn[34].setOnAction(e->setDisplay(all_btn[34],34));
             all_btn[35].setOnAction(e->setDisplay(all_btn[35],35));
             all_btn[36].setOnAction(e->setDisplay(all_btn[36],36));
             all_btn[37].setOnAction(e->setDisplay(all_btn[37],37));
             all_btn[38].setOnAction(e->setDisplay(all_btn[38],38));
             all_btn[39].setOnAction(e->setDisplay(all_btn[39],39));
             all_btn[40].setOnAction(e->setDisplay(all_btn[40],40));
             all_btn[41].setOnAction(e->setDisplay(all_btn[41],41));
             all_btn[42].setOnAction(e->setDisplay(all_btn[42],42));
             all_btn[43].setOnAction(e->setDisplay(all_btn[43],43));
             all_btn[44].setOnAction(e->setDisplay(all_btn[44],44));
             all_btn[45].setOnAction(e->setDisplay(all_btn[45],45));
             all_btn[46].setOnAction(e->setDisplay(all_btn[46],46));
             all_btn[47].setOnAction(e->setDisplay(all_btn[47],47));
             all_btn[48].setOnAction(e->setDisplay(all_btn[48],48));
             all_btn[49].setOnAction(e->setDisplay(all_btn[49],49));
             all_btn[50].setOnAction(e->setDisplay(all_btn[50],50));
             all_btn[51].setOnAction(e->setDisplay(all_btn[51],51));
             all_btn[52].setOnAction(e->setDisplay(all_btn[52],52));
             all_btn[53].setOnAction(e->setDisplay(all_btn[53],53));
             all_btn[54].setOnAction(e->setDisplay(all_btn[54],54));
             all_btn[55].setOnAction(e->setDisplay(all_btn[55],55));
             all_btn[56].setOnAction(e->setDisplay(all_btn[56],56));
             all_btn[57].setOnAction(e->setDisplay(all_btn[57],57));
             all_btn[58].setOnAction(e->setDisplay(all_btn[58],58));
             all_btn[59].setOnAction(e->setDisplay(all_btn[59],59));
             all_btn[60].setOnAction(e->setDisplay(all_btn[60],60));
             all_btn[61].setOnAction(e->setDisplay(all_btn[61],61));
             all_btn[62].setOnAction(e->setDisplay(all_btn[62],62));
             all_btn[63].setOnAction(e->setDisplay(all_btn[63],63));
             all_btn[64].setOnAction(e->setDisplay(all_btn[64],64));
             all_btn[65].setOnAction(e->setDisplay(all_btn[65],65));
             all_btn[66].setOnAction(e->setDisplay(all_btn[66],66));
             all_btn[67].setOnAction(e->setDisplay(all_btn[67],67));
             all_btn[68].setOnAction(e->setDisplay(all_btn[68],68));
             all_btn[69].setOnAction(e->setDisplay(all_btn[69],69));
             all_btn[70].setOnAction(e->setDisplay(all_btn[70],70));
             all_btn[71].setOnAction(e->setDisplay(all_btn[71],71));
             all_btn[72].setOnAction(e->setDisplay(all_btn[72],72));
             all_btn[73].setOnAction(e->setDisplay(all_btn[73],73));
             all_btn[74].setOnAction(e->setDisplay(all_btn[74],74));
             all_btn[75].setOnAction(e->setDisplay(all_btn[75],75));
             all_btn[76].setOnAction(e->setDisplay(all_btn[76],76));
             all_btn[77].setOnAction(e->setDisplay(all_btn[77],77));
             all_btn[78].setOnAction(e->setDisplay(all_btn[78],78));
             all_btn[79].setOnAction(e->setDisplay(all_btn[79],79));
             all_btn[80].setOnAction(e->setDisplay(all_btn[80],80));
             all_btn[81].setOnAction(e->setDisplay(all_btn[81],81));
             all_btn[82].setOnAction(e->setDisplay(all_btn[82],82));
             all_btn[83].setOnAction(e->setDisplay(all_btn[83],83));

             movie = new Label("Movie");
             movie.setFont(new Font("Verdana",14));
             movie.setTextFill(Color.rgb(255,165,0));
             movie.setPrefSize(70,25);

             time = new Label("Time");
             time.setFont(new Font("Verdana",14));
             time.setTextFill(Color.rgb(255,165,0));
             time.setPrefSize(70,25);

             tickets = new Label("Tickets");
             tickets.setFont(new Font("Verdana",14));
             tickets.setTextFill(Color.rgb(255,165,0));
             tickets.setPrefSize(70,25);

             total = new Label("Total");
             total.setFont(new Font("Verdana",14));
             total.setTextFill(Color.rgb(255,165,0));
             total.setPrefSize(70,25);

             seats = new Label("Seats");
             seats.setFont(new Font("Verdana",14));
             seats.setTextFill(Color.rgb(255,165,0));
             seats.setPrefSize(70,25);

             movie_ans = new Label(": Movie");
             movie_ans.setFont(new Font("Verdana",14));
             movie_ans.setPrefSize(200,25);

             time_ans = new Label(": August 12, 10:30");
             time_ans.setFont(new Font("Verdana",14));
             time_ans.setPrefSize(500,25);

             tickets_ans = new Label(": 0");
             tickets_ans.setFont(new Font("Verdana",14));
             tickets_ans.setPrefSize(200,25);

             total_ans = new Label(": $ 0");
             total_ans.setFont(new Font("Verdana",14));
             total_ans.setPrefSize(200,25);

             seats_ans = new Label(": ");
             seats_ans.setFont(new Font("Verdana",14));
             seats_ans.setPrefSize(2200,25);

             book = new Button("Book now");
             book.setStyle("-fx-background-color: #FFA500");
             book.setTextFill(Color.rgb(255,255,255));
             book.setFont(new Font("Verdana",14));
             book.setPadding(new Insets(8,8,8,8));
             book.setOnAction(e->{
                 for(int i=0;i<84;i++){
                     if(selected_btn[i]!=null){
                         selected_btn[i].setStyle("-fx-background-color:#EE4B2B");
                         selected_btn[i].setOnAction(f->{});
                     }
                 }
                 tickets_ans.setText(": 0");
                 total_ans.setText(": Rupees 0");
                 seats_ans.setText(": ");
                 seats_val = ": ";
                 count += ticket;
                 if(count==all_btn.length){
                     book.setDisable(true);
                 }
                 ticket = 0;
                 amount = 0;
                 Button[] temp_btn = new Button[84];
                 selected_btn = temp_btn;
                 stage.close();
             });

             b_available = new Button();
             b_available.setStyle("-fx-background-color:#B2BEB5");
             b_available.setPrefSize(30,35);

             b_sold = new Button();
             b_sold.setStyle("-fx-background-color:#EE4B2B");
             b_sold.setPrefSize(30,35);

             b_selected = new Button();
             b_selected.setStyle("-fx-background-color:#32CD32");
             b_selected.setPrefSize(30,35);

             available = new Label("Available");
             available.setFont(new Font("Verdana",14));
             available.setAlignment(Pos.CENTER_LEFT);
             available.setPadding(new Insets(7,50,5,3));

             sold = new Label("Sold");
             sold.setFont(new Font("Verdana",14));
             sold.setAlignment(Pos.CENTER_LEFT);
             sold.setPadding(new Insets(7,50,5,3));

             selected = new Label("Selected");
             selected.setFont(new Font("Verdana",14));
             selected.setAlignment(Pos.CENTER_LEFT);
             selected.setPadding(new Insets(7,50,5,3));

             VBox temp1 = new VBox();
             temp1.getChildren().addAll(movie,time,tickets,total,seats);
             temp1.setMinSize(70,0);

             VBox temp2 = new VBox();
             temp2.getChildren().addAll(movie_ans,time_ans,tickets_ans,total_ans,seats_ans);
             temp2.setMinSize(70,0);

             HBox h1 = new HBox();
             h1.getChildren().addAll(temp1,temp2);
             h1.setPadding(new Insets(5,5,5,5));
             h1.setSpacing(10);

             HBox h6 = new HBox();
             h6.getChildren().add(book);
             h6.setPadding(new Insets(20,5,20,5));
             h6.setSpacing(10);

             HBox h7 = new HBox();
             h7.getChildren().addAll(b_available,available);
             h7.setPadding(new Insets(5,5,5,5));
             h7.setSpacing(10);

             HBox h8 = new HBox();
             h8.getChildren().addAll(b_sold,sold);
             h8.setPadding(new Insets(5,5,5,5));
             h8.setSpacing(10);

             HBox h9 = new HBox();
             h9.getChildren().addAll(b_selected,selected);
             h9.setPadding(new Insets(5,5,5,5));
             h9.setSpacing(10);

             //separate left and right side using separator
             Separator s = new Separator();
             s.setOrientation(Orientation.VERTICAL);
             s.setMinSize(20,0);

             VBox vb2 = new VBox();
             vb2.getChildren().addAll(h1,h6,h7,h8,h9);
             vb2.setMaxSize(2500,2500);

             HBox mainHB = new HBox();
             mainHB.getChildren().addAll(vb1,s,vb2);

             VBox mainVB = new VBox();
             mainVB.setAlignment(Pos.TOP_CENTER);
             mainVB.getChildren().addAll(title,mainHB);
           
             //set scene and show
             Scene sc = new Scene(mainVB,770,610);
             stage.setScene(sc);
             stage.show();
             stage.setTitle(" Theatre Showing Screen");
             stage.setMinHeight(650);
             stage.setMinWidth(800);
         }
     
 
  public void CardPage() {
 Label R = new Label("Total Seats Selected : "+c); R.setStyle("-fx-font: normal bold 15px 'serif' "); 
 Label P = new Label("Total Payable Amount : "+ r); P.setStyle("-fx-font: normal bold 15px 'serif' "); 
       Button Book = new Button("Pay "+ r); Book.setStyle("-fx-font: normal bold 15px 'serif' "); 
      Button Back = new Button("< Back");    
       
     Label CN = new Label("Enter Your Card Number :"); CN.setStyle("-fx-font: normal bold 15px 'serif' "); 
     Label cvv = new Label("Enter Your cvv :"); cvv.setStyle("-fx-font: normal bold 15px 'serif' "); 
     Label ce = new Label("Enter Card Expiry Date :"); ce.setStyle("-fx-font: normal bold 15px 'serif' "); 
     Label cn = new Label("Enter Card Holder Name :"); cn.setStyle("-fx-font: normal bold 15px 'serif' "); 
     final TextField t1 = new TextField();
     final TextField t2 = new TextField();
     final TextField t3 = new TextField();
     final TextField t4 = new TextField();
       
       Book.setPrefSize(200, 80);
final Stage stage = new Stage();
 final GridPane gp = new GridPane();
 gp.add(P, 0, 3);
 gp.add(CN, 0, 4);
 gp.add(cvv, 0, 5);
 gp.add(ce, 0, 6);
 gp.add(cn, 0, 7);
 gp.add(t1, 1, 4);
 gp.add(t2, 1, 5);
 gp.add(t3, 1, 6);
 gp.add(t4, 1, 7);
 gp.add(Back, 0, 0);
 gp.add(Book, 1, 9);
 gp.add(R, 0, 8);
 gp.setPrefSize(500, 650);

gp.setPadding(new Insets(10, 10, 10, 10));
   gp.setVgap(5);
   gp.setHgap(5);
gp.setAlignment(Pos.CENTER);
Image img = new Image("C:\\Users\\RAVI GUPTA\\Downloads\\BackgroundImage.jpg");
        BackgroundImage bImg = new BackgroundImage(img,
                                                   BackgroundRepeat.REPEAT,
                                                   BackgroundRepeat.REPEAT,
                                                   BackgroundPosition.DEFAULT,
                                                   BackgroundSize.DEFAULT);
        Background bGround = new Background(bImg);
        gp.setBackground(bGround);
Scene scene = new Scene(gp);
stage.setTitle(" ");
stage.setScene(scene);
        stage.show();
        final Duration SEC_2 = Duration.millis(1800);    
   TranslateTransition tt = new TranslateTransition(SEC_2);
    tt.setFromX(100f);
    tt.setToX(-10f);
    tt.setCycleCount((int) 1f);
    tt.setAutoReverse(true);
    ParallelTransition pt = new ParallelTransition(gp, tt);
    pt.play();
        Book.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent event) {
            stage.close();
           
           }});
        Back.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent event) {
            stage.close();
                Payshow.show();
           }});
       
        Book.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	try {
            	 String	t = t1.getText(); String y = t2.getText();
                 int f = Integer.parseInt(t); int u = Integer.parseInt(y);
                 int length = (int) (Math.log10(f) + 1); int lengt = (int) (Math.log10(u) + 1);
                 if (length!=16) {
             		showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Payment Error","Please enter valid Card Number"); 
                 }
                 if (lengt!=3) {
                	 showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Payment Error","Please enter valid Card CVV");  
                 }              
            	}
            	catch(Exception e){
            		showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Payment Error","Please enter valid Card Details"); 
            	}
            	 
                if(t1.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter your Card Number");
                    return;             
                }
                if(t2.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter your CVV");
                    return;
                }
                if(t3.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter your Card's Expiry Date");
                    return;
                }
                if(t4.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter your Card's Holder Name");
                    return;
                }
                {   stage.close();
                    Payshow.close();
                    homePage();
                    showAlert(Alert.AlertType.CONFIRMATION, gp.getScene().getWindow(), " ", "Payment Successful! THANK YOU!!! ");
                }
            }            
            });
    }
 
  public void AppPage() {
 Label P = new Label("Total Payable Amount : "+ r);
      Button Book = new Button("Pay "+r);  Button Back = new Button("< Back");
      Label R = new Label("Total Seats Selected : "+c);
      Label CN = new Label("Enter Your Mobile Number :");
      Label cvv = new Label("Enter Your \"Username @upi\" :");
     
      final TextField t1 = new TextField();
      final TextField t2 = new TextField();
       
Stage stage = new Stage();
 final GridPane gp = new GridPane();
 gp.add(P, 1, 2); P.setStyle("-fx-font: normal bold 15px 'serif' "); 
 gp.add(CN, 1, 4); gp.add(Back, 0, 0); CN.setStyle("-fx-font: normal bold 15px 'serif' "); 
 gp.add(cvv, 1, 5); cvv.setStyle("-fx-font: normal bold 15px 'serif' "); 
 gp.add(t1, 2, 4);
 gp.add(t2, 2, 5); gp.add(R, 1, 3); R.setStyle("-fx-font: normal bold 15px 'serif' "); 
 gp.add(Book, 2, 7); Book.setStyle("-fx-font: normal bold 15px 'serif' "); 

gp.setPadding(new Insets(10, 10, 10, 10));
   gp.setVgap(5);
   gp.setHgap(5);
gp.setAlignment(Pos.CENTER);
Image img = new Image("C:\\Users\\RAVI GUPTA\\Downloads\\BackgroundImage.jpg");
        BackgroundImage bImg = new BackgroundImage(img,
                                                   BackgroundRepeat.REPEAT,
                                                   BackgroundRepeat.REPEAT,
                                                   BackgroundPosition.DEFAULT,
                                                   BackgroundSize.DEFAULT);
        Background bGround = new Background(bImg);
        gp.setBackground(bGround);
Scene scene = new Scene(gp);
stage.setTitle(" ");
stage.setScene(scene);
        stage.show();
        final Duration SEC_2 = Duration.millis(1800);    
   TranslateTransition tt = new TranslateTransition(SEC_2);
    tt.setFromX(100f);
    tt.setToX(-10f);
    tt.setCycleCount((int) 1f);
    tt.setAutoReverse(true);
    ParallelTransition pt = new ParallelTransition(gp, tt);
    pt.play();
    Book.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
        	try {
           	 String	t = t1.getText(); 
                int f = Integer.parseInt(t); 
                int length = (int) (Math.log10(f) + 1); 
                if (length!=10) {
            		showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Payment Error","Please enter valid Card Number"); 
                }
                            
           	}
           	catch(Exception e){
           		showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Payment Error","Please enter valid Card Details"); 
           	}
            if(t1.getText().isEmpty()) {
                showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter your Mobile Number");
                return;
            }
            if(t2.getText().isEmpty()) {
                showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter your Username@UPI ");
                return;
            }
            {
            	stage.close();
                Payshow.close();
                homePage();
                showAlert(Alert.AlertType.CONFIRMATION, gp.getScene().getWindow(), " ", "Payment Successful! THANK YOU!!! ");
            }
        }
        });
        Back.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            stage.close();
            Payshow.show();
            }});
  }
  public void UPI(){
 Label P = new Label("Total Payable Amount : "+ r); P.setStyle("-fx-font: normal bold 15px 'serif' "); 
     Button Book = new Button("Pay "+ r); Book.setStyle("-fx-font: normal bold 15px 'serif' "); 
     Button Back = new Button("< Back");
      Label CN = new Label("Enter Your Virtual Payment Address :"); CN.setStyle("-fx-font: normal bold 15px 'serif' "); 
      Label R = new Label("Total Seats Selected : "+c); R.setStyle("-fx-font: normal bold 15px 'serif' "); 
      final TextField t1 = new TextField();
Stage stage = new Stage();
 final GridPane gp = new GridPane();
 gp.add(P, 1, 3);
 gp.add(CN, 1, 4);
 gp.add(t1, 2, 4); gp.add(Back, 0, 0);
 gp.add(R, 1, 2);
 gp.add(Book, 2, 7);
gp.setPadding(new Insets(10, 10, 10, 10));
   gp.setVgap(5);
   gp.setHgap(5);
   gp.setPrefSize(500, 650);
gp.setAlignment(Pos.CENTER);
Image img = new Image("C:\\Users\\RAVI GUPTA\\Downloads\\BackgroundImage.jpg");
        BackgroundImage bImg = new BackgroundImage(img,
                                                   BackgroundRepeat.REPEAT,
                                                   BackgroundRepeat.REPEAT,
                                                   BackgroundPosition.DEFAULT,
                                                   BackgroundSize.DEFAULT);
        Background bGround = new Background(bImg);
        gp.setBackground(bGround);
Scene scene = new Scene(gp);
stage.setTitle("UPI");
stage.setScene(scene);
        stage.show();
        final Duration SEC_2 = Duration.millis(1800);    
   TranslateTransition tt = new TranslateTransition(SEC_2);
    tt.setFromX(100f);
    tt.setToX(-10f);
    tt.setCycleCount((int) 1f);
    tt.setAutoReverse(true);
    ParallelTransition pt = new ParallelTransition(gp, tt);
    pt.play();
        Book.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
               
                if(t1.getText().isEmpty()) {
                    showAlert(Alert.AlertType.ERROR, gp.getScene().getWindow(), "Form Error!", "Please enter your Virtual Payment Address ");
                    return;
                }
                stage.close();
                Payshow.close();
                 homePage();
                showAlert(Alert.AlertType.CONFIRMATION, gp.getScene().getWindow(), " ", " Payment Successful!! Thank You!! ");
                
            }
            }); Back.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent event) {
            stage.close();
                Payshow.show();
           }});}  }
         }
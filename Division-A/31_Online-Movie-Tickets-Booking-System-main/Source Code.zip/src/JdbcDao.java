import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JdbcDao {
		private static final String JDBC_Driver = "com.mysql.jdbc.Driver";
		private	static final String DATABASE_URL = "jdbc:mysql://localhost/girrafe";
		private	static final String DATABASE_USERNAME = "root";
		private static final String DATABASE_PASSWORD = "Shiva@2001";
		private static final String SELECT_QUERY = "Select * from customer WHERE emailId =? and password =?";
		private static final String SELECT_QUERY1 = "Select * from admin where Login_id=? and Password=?";
		public boolean validate(String emailId, String password) throws SQLException
		{
			try(Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
					
					PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY))
						{
				         preparedStatement.setString(1,emailId);
					     preparedStatement.setString(2, password);
					
					     System.out.println(preparedStatement);
					
					     ResultSet resultSet = preparedStatement.executeQuery();
					     if(resultSet.next())
					      {
						   return true;
					     }
				    }
			
			catch(SQLException e)
			{
				printSQLException(e);	
			}
			return false;
			
		}
		
		public static void printSQLException(SQLException ex)
		{
			for (Throwable e:ex)
			{
				if (e instanceof SQLException)
				{
					e.printStackTrace(System.err);
					System.err.println("SQLState:" + ((SQLException) e).getSQLState());
					System.err.println("Error Code:" + ((SQLException) e).getErrorCode());
					System.err.println("Message:" + e.getMessage());
					Throwable t = ex.getCause();
					while(t!=null)
					{
						System.out.println("Cause:" + t);
						t=t.getCause();
					}
				}
			}
		}

		public boolean validate1(String Login_id, String Password) throws SQLException {
	try(Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
					
					PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY1))
						{
				         preparedStatement.setString(1, Login_id);
					     preparedStatement.setString(2, Password);
					
					     System.out.println(preparedStatement);
					
					     ResultSet resultSet = preparedStatement.executeQuery();
					     if(resultSet.next())
					      {
						   return true;
					     }
				    }
			
			catch(SQLException e)
			{
				printSQLException(e);	
			}
			return false;
			
		}
		
		public static void printSQLException1(SQLException ex)
		{
			for (Throwable e:ex)
			{
				if (e instanceof SQLException)
				{
					e.printStackTrace(System.err);
					System.err.println("SQLState:" + ((SQLException) e).getSQLState());
					System.err.println("Error Code:" + ((SQLException) e).getErrorCode());
					System.err.println("Message:" + e.getMessage());
					Throwable t = ex.getCause();
					while(t!=null)
					{
						System.out.println("Cause:" + t);
						t=t.getCause();
					}
				}
			}
		}
}

-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: girrafe
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `seats`
--

DROP TABLE IF EXISTS `seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seats` (
  `Seat_no` varchar(10) NOT NULL,
  `Seat_Price` int DEFAULT NULL,
  PRIMARY KEY (`Seat_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seats`
--

LOCK TABLES `seats` WRITE;
/*!40000 ALTER TABLE `seats` DISABLE KEYS */;
INSERT INTO `seats` VALUES ('r10c3',120),('r10c4',120),('r10c5',120),('r10c6',120),('r10c7',120),('r10c8',120),('r1c1',120),('r1c10',120),('r1c2',120),('r1c3',120),('r1c4',120),('r1c5',120),('r1c6',120),('r1c7',120),('r1c8',120),('r1c9',120),('r2c1',120),('r2c10',120),('r2c2',120),('r2c3',120),('r2c4',120),('r2c5',120),('r2c6',120),('r2c7',120),('r2c8',120),('r2c9',120),('r4c1',120),('r4c2',120),('r4c3',120),('r4c4',120),('r4c5',120),('r4c6',120),('r4c7',120),('r4c8',120),('r4c9',120),('r5c1',120),('r5c10',120),('r5c2',120),('r5c3',120),('r5c4',120),('r5c5',120),('r5c6',120),('r5c7',120),('r5c8',120),('r5c9',120),('r6c1',120),('r6c10',120),('r6c2',120),('r6c3',120),('r6c4',120),('r6c5',120),('r6c6',120),('r6c7',120),('r6c8',120),('r6c9',120),('r7c1',120),('r7c10',120),('r7c2',120),('r7c3',120),('r7c4',120),('r7c5',120),('r7c6',120),('r7c7',120),('r7c8',120),('r7c9',120),('r8c1',120),('r8c10',120),('r8c2',120),('r8c3',120),('r8c4',120),('r8c5',120),('r8c6',120),('r8c7',120),('r8c8',120),('r8c9',120),('r9c1',120),('r9c10',120),('r9c2',120),('r9c3',120),('r9c4',120),('r9c5',120),('r9c6',120),('r9c7',120),('r9c8',120),('r9c9',120);
/*!40000 ALTER TABLE `seats` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-08 20:32:24

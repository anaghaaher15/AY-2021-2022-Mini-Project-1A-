package sql;
//JDBC DRIVER VERSION 8.0.26
public class conn {
    public static final String Conn_user = "Chiragsp";
    public static final String Conn_pw = "admin";
    public static final String Conn = "jdbc:mysql://localhost:3306/student";
}

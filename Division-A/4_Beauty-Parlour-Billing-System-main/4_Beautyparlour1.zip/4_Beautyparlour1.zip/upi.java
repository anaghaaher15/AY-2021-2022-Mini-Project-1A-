package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class upi extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField txtOk;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					upi frame = new upi();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public upi() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 808, 596);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 245, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("4_Beautyparlour1.zip\\images\\qr1.jpg"));
		lblNewLabel.setBounds(524, 267, 258, 301);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("4_Beautyparlour1.zip\\images\\UPIPAYYY.jpg"));
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 55));
		lblNewLabel_1.setBounds(-39, 0, 881, 145);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("UPI ID :");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 23));
		lblNewLabel_2.setBounds(40, 154, 297, 35);
		contentPane.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		textField.setBounds(40, 200, 237, 45);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("@");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 34));
		lblNewLabel_3.setBounds(287, 197, 54, 48);
		contentPane.add(lblNewLabel_3);
		
		txtOk = new JTextField();
		txtOk.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		txtOk.setColumns(10);
		txtOk.setBounds(341, 200, 151, 45);
		contentPane.add(txtOk);
		
		JLabel lblNewLabel_4 = new JLabel("QR CODE TO SCAN:");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 23));
		lblNewLabel_4.setBounds(512, 245, 306, 45);
		contentPane.add(lblNewLabel_4);
		
		JButton btnNewButton = new JButton("PAY");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 JOptionPane.showMessageDialog(null,"Please complete the payment on your UPI PAYMENT APPLICATION.");  
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(139, 69, 19));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton.setBounds(40, 267, 242, 48);
		contentPane.add(btnNewButton);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PAYMENU paym= new PAYMENU();
				paym.setVisible(true);
				dispose();
			}
		});
		btnBack.setForeground(Color.WHITE);
		btnBack.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnBack.setBackground(new Color(139, 69, 19));
		btnBack.setBounds(39, 333, 242, 48);
		contentPane.add(btnBack);
		
		JButton btnRestart = new JButton("RESTART");
		btnRestart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				beautyparlour bp=new beautyparlour();
				bp.setVisible(true);
				dispose();
			}
		});
		btnRestart.setForeground(Color.WHITE);
		btnRestart.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnRestart.setBackground(new Color(139, 69, 19));
		btnRestart.setBounds(39, 395, 242, 48);
		contentPane.add(btnRestart);
		
		JButton btnNewButton_1_1 = new JButton("EXIT");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				end en=new end();
				en.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		btnNewButton_1_1.setBackground(new Color(139, 69, 19));
		btnNewButton_1_1.setBounds(39, 454, 242, 48);
		contentPane.add(btnNewButton_1_1);
	}

}

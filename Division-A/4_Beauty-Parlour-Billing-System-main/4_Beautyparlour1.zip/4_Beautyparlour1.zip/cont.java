package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class cont extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cont frame = new cont();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**  
	 * Create the frame.  
	 */
	public cont() {
		setBounds(100, 100, 582, 398);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("4_Beautyparlour1.zip\\images\\Screenshot 2021-11-28 191802.png"));
		lblNewLabel.setBounds(-12, -20, 608, 260);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("    \r\nSANIYA DUTTA    +91 9653282317    \r\n\r\n");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(115, 265, 314, 43);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\r\nANISH BHOSALE  +91 7506930557    \r\n");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_1_1.setBounds(132, 288, 339, 60);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("SHREYA MAHAJAN  +91 7045508960    \r\n\r\n\r\n");
		lblNewLabel_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 11));
		lblNewLabel_1_1_1.setBounds(632, 223, 178, 67);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("SHREYA MAHAJAN  +91 7045508960    \r\n\r\n\r\n");
		lblNewLabel_1_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_1_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_1_1_2.setBounds(134, 218, 556, 75);
		contentPane.add(lblNewLabel_1_1_2);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				beautyparlour bp=new beautyparlour();
	           bp.setVisible(true);
	           dispose();
	         
			}
		});
		btnNewButton.setBounds(481, 325, 75, 23);
		contentPane.add(btnNewButton);
	}

}

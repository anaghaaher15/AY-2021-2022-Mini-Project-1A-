package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.sql.DriverManager;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class CREATEACC extends JFrame {
private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField firstname_1;
	private JTextField lastname_1;
	private JTextField mob_1;
	private JTextField username_1;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CREATEACC frame = new CREATEACC();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	Connection conn= null;
	public CREATEACC() {
		conn = (Connection) ConnectDB.dbconnect();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 444);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 245, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("4_Beautyparlour1.zip\\images\\CREATE.jpg"));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 36));
		lblNewLabel.setBounds(-34, -6, 730, 99);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("NAME           :");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1.setBounds(33, 104, 144, 35);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("SURNAME   :");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(33, 150, 144, 35);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("MOBILE NO:");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1_1_1.setBounds(33, 196, 144, 35);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("USERNAME :");
		lblNewLabel_1_1_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1_1_2.setBounds(33, 242, 144, 35);
		contentPane.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("PASSWORD :");
		lblNewLabel_1_1_3.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1_1_3.setBounds(33, 293, 144, 35);
		contentPane.add(lblNewLabel_1_1_3);
		
		firstname_1 = new JTextField();
		firstname_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		firstname_1.setBounds(178, 104, 351, 35);
		contentPane.add(firstname_1);
		firstname_1.setColumns(10);
		
		lastname_1 = new JTextField();
		lastname_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lastname_1.setColumns(10);
		lastname_1.setBounds(178, 150, 351, 35);
		contentPane.add(lastname_1);
		
		mob_1 = new JTextField();
		mob_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		mob_1.setColumns(10);
		mob_1.setBounds(178, 196, 351, 35);
		contentPane.add(mob_1);
		
		username_1 = new JTextField();
		username_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		username_1.setColumns(10);
		username_1.setBounds(178, 242, 351, 35);
		contentPane.add(username_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(178, 285, 351, 35);
		contentPane.add(passwordField);
		
		final JButton btnNewButton_1 = new JButton("CREATE");
		btnNewButton_1.addActionListener(new ActionListener()
		{
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				String firstName = firstname_1.getText();
                String lastName = lastname_1.getText();
                
                String userName = username_1.getText();
                String mobileNumber = mob_1.getText();
                int len = mobileNumber.length();
                String password = passwordField.getText();
String msg="Hello,";
                 msg = "" + firstName;
                msg += " \n";
                if (len != 10) {
                    JOptionPane.showMessageDialog(btnNewButton_1, "Enter a valid mobile number");
                

                try {
                    Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/beautyparlourdb", "root", "Project@123");

                    String query = "INSERT INTO beautyparlourdb.register('" + firstname_1 + "','" + lastname_1 + "','" + username_1 + "','" +
                        passwordField +  "','" + mob_1 + "')";

                    Statement sta = (Statement) conn.createStatement();
                    int x = sta.executeUpdate(query);
                    if (x == 0) {
                        JOptionPane.showMessageDialog(btnNewButton_1, "This acc already exists");
                    } else {
                        JOptionPane.showMessageDialog(btnNewButton_1,
                            "Welcome, " + msg + "Your account is sucessfully created");
                    }
                    conn.close();
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
                }
                else
                {
			 JOptionPane.showMessageDialog(null,"Your account has been created successfully.");  
			 				 
			INVENTORY inv=new INVENTORY();
			inv.setVisible(true);
			dispose();
			}
			}
		});
		
		btnNewButton_1.setBounds(84, 339, 408, 35);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("CREATE");
		btnNewButton.addActionListener(new ActionListener() {
			private String firstname;

			public void actionPerformed(ActionEvent e) {
				
				firstname = firstname_1.getText();
				String lastname = lastname_1.getText();
				String mob = mob_1.getText();
				int len = mob.length();
			
				String username = username_1.getText();
				String password = passwordField.getText();
				
				String msg = "" + firstname_1;
				msg+="\n";
				if(len != 10)
				{
					JOptionPane.showMessageDialog(btnNewButton_1,"ENTER A VALID MOBILE NUMBER");
				}
				
				
			}
		});
		btnNewButton.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				String firstName = firstname_1.getText();
                String lastName = lastname_1.getText();
                
                String userName = username_1.getText();
                String mobileNumber = mob_1.getText();
                int len = mobileNumber.length();
                String password = passwordField.getText();

                String msg = "" + firstName;
                msg += " \n";
                if (len != 10) {
                    JOptionPane.showMessageDialog(btnNewButton_1, "Enter a valid mobile number");
                }

                try {
                    Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/beautyparlourDB", "root", "Project@123");

                    String query = "INSERT INTO account values('" + firstName + "','" + lastName + "','" + userName + "','" +
                        password +  "','" + mobileNumber + "')";

                    Statement sta = (Statement) conn.createStatement();
                    int x = sta.executeUpdate(query);
                    if (x == 0) {
                        JOptionPane.showMessageDialog(btnNewButton_1, "This acc already exists");
                    } else {
                        JOptionPane.showMessageDialog(btnNewButton_1,
                            "Welcome, " + msg + "Your account is sucessfully created");
                    }
                    conn.close();
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
   		
			
		});
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 26));
		btnNewButton_1.setBackground(new Color(139, 69, 19));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setBounds(79, 326, 408, 56);
contentPane.add(btnNewButton_1);
	}
}




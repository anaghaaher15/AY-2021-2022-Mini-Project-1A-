package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class MAINMENU extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MAINMENU frame = new MAINMENU();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MAINMENU() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 694, 444);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 228, 225));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(new Color(139, 69, 19));
		lblNewLabel.setIcon(new ImageIcon("4_Beautyparlour1.zip\\images\\MM.jpg"));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 40));
		lblNewLabel.setBounds(0, -56, 743, 318);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("LOGIN AN EXISTING USER");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				loginpage log = new loginpage();
		       log.setVisible(true);
		       dispose();
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(139, 69, 19));
		btnNewButton.setBounds(0, 224, 676, 78);
		contentPane.add(btnNewButton);
		
		JButton btnCreateANew = new JButton("CREATE A NEW USER ACCOUNT");
		btnCreateANew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				CREATEACC create = new CREATEACC();
				create.setVisible(true);
				dispose();
			}
		});
		btnCreateANew.setForeground(new Color(255, 255, 255));
		btnCreateANew.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnCreateANew.setBackground(new Color(139, 69, 19));
		btnCreateANew.setBounds(0, 313, 676, 70);
		contentPane.add(btnCreateANew);
	}

}

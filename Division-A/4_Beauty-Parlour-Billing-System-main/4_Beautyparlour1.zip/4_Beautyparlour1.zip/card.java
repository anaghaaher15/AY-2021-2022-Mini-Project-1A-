package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class card extends JFrame {

	private JPanel contentPane;
	private JTextField cardnum;
	private JTextField textField_1;
	private JTextField textField_2;
	private JPasswordField cvv;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					card frame = new card();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public card() {
		setBackground(new Color(0, 0, 0));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 972, 699);
		contentPane = new JPanel();
		contentPane.setToolTipText("000");
		contentPane.setBackground(new Color(255, 245, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("4_Beautyparlour1.zip\\images\\\\CP.jpg"));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 42));
		lblNewLabel.setBounds(0, -16, 1094, 165);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("CARD NUMBER");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1.setBounds(45, 174, 344, 27);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("NAME ON THE CARD");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1_1.setBounds(45, 260, 278, 27);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("EXPIRY DATE");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1_1_1.setBounds(45, 350, 278, 27);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("CVV CODE");
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1_1_1_1.setBounds(659, 350, 153, 27);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		JButton btnNewButton = new JButton("PAY");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cardno=cardnum.getText();
				@SuppressWarnings("deprecation")
				String cvvcode =cvv.getText();
				int len1=cardno.length();
				int len2=cvvcode.length();
				if(len1==12 || len2==3)
				{
				 JOptionPane.showMessageDialog(null,"Payment Successful!");  
				 end en=new end();
				 en.setVisible(true);
				 dispose();
			}
				else
				{
					 JOptionPane.showMessageDialog(null,"Invalid card number or cvv. Please retry.");  
				}
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(139, 69, 19));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 28));
		btnNewButton.setBounds(10, 449, 932, 52);
		contentPane.add(btnNewButton);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("REMEMBER");
		chckbxNewCheckBox.setForeground(new Color(255, 255, 255));
		chckbxNewCheckBox.setBackground(new Color(139, 69, 19));
		chckbxNewCheckBox.setFont(new Font("Times New Roman", Font.BOLD, 20));
		chckbxNewCheckBox.setBounds(774, 168, 160, 33);
		contentPane.add(chckbxNewCheckBox);
		
		cardnum = new JTextField();
		cardnum.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		cardnum.setBounds(45, 206, 541, 41);
		contentPane.add(cardnum);
		cardnum.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		textField_1.setColumns(10);
		textField_1.setBounds(45, 298, 541, 41);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		textField_2.setText("       /");
		textField_2.setColumns(10);
		textField_2.setBounds(45, 388, 354, 51);
		contentPane.add(textField_2);
		
		cvv = new JPasswordField();
		cvv.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		cvv.setToolTipText("***");
		cvv.setBounds(656, 390, 241, 47);
		contentPane.add(cvv);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PAYMENU paym= new PAYMENU();
				paym.setVisible(true);
				dispose();
			}
		});
		btnBack.setForeground(Color.WHITE);
		btnBack.setFont(new Font("Times New Roman", Font.BOLD, 28));
		btnBack.setBackground(new Color(139, 69, 19));
		btnBack.setBounds(10, 512, 932, 52);
		contentPane.add(btnBack);
		
		JButton btnNewButton_3_1 = new JButton("EXIT");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				end en= new end();
				en.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_3_1.setForeground(Color.WHITE);
		btnNewButton_3_1.setFont(new Font("Times New Roman", Font.BOLD, 28));
		btnNewButton_3_1.setBackground(new Color(139, 69, 19));
		btnNewButton_3_1.setBounds(10, 575, 932, 52);
		contentPane.add(btnNewButton_3_1);
	}
}

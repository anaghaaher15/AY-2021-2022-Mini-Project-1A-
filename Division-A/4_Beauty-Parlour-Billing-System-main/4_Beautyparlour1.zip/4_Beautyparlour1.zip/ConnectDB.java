package project;




import javax.swing.*;

import com.mysql.jdbc.Statement;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;

@SuppressWarnings("unused")

public class ConnectDB
{
Connection conn=null;
java.sql.PreparedStatement pst;
public static Connection dbconnect()
{

try{
	Class.forName("com.mysql.cj.jdbc.Driver");
Connection conn = (Connection)DriverManager.getConnection("jdbc:mysql//localhost:3306/beautyparlourdb","root","Project@123");

if(conn!=null)
{
System.out.println("Connected to database");
return conn;
}
}
catch(Exception e)
{
System.out.println("Not connected to database.");

}
return null;

}

private void execute()
{
try {
	Statement stmt =(Statement) conn.createStatement();
	ResultSet result = stmt.executeQuery("SELECT * FROM beautyparlourdb");
	while (result.next())
	{
		 System.out.println(result.getString(1) +""+result.getInt(2));
		 
	}
}
}
}

package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JCheckBox;
import javax.swing.border.BevelBorder;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JScrollBar;

public class INVENTORY extends JFrame {

	private JPanel contentPane;
	private JTable jTable1;
	private JTextField txtsub;
	private JTextField txtpay;
	private JTextField txtbal;
	private JCheckBox chk1;
	private JCheckBox chk2;
	private JCheckBox chk3;
	private JCheckBox chk4;
	private JCheckBox chk5;
	private JCheckBox chk6;
	private JCheckBox chk7;
	private JCheckBox chk8;
	private JCheckBox chk9;
	private JCheckBox chk10;
	private JButton BACK;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					INVENTORY frame = new INVENTORY();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public INVENTORY() {
		  @SuppressWarnings("unused")
		DefaultTableModel model= new DefaultTableModel();

		setBackground(new Color(0, 100, 0));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 764, 797);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(253, 245, 230));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		chk1 = new JCheckBox("Hair cut");
		chk1.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk1.setForeground(new Color(255, 255, 255));
		chk1.setBackground(new Color(139, 69, 19));
		chk1.setBounds(27, 362, 202, 23);
		contentPane.add(chk1);
		
		chk2 = new JCheckBox("Hair wash + Blowdry");
		chk2.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk2.setForeground(new Color(255, 255, 255));
		chk2.setBackground(new Color(139, 69, 19));
		chk2.setBounds(27, 388, 202, 23);
		contentPane.add(chk2);
		
		chk3 = new JCheckBox("Hair colour - Balayage");
		chk3.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk3.setForeground(new Color(255, 255, 255));
		chk3.setBackground(new Color(139, 69, 19));
		chk3.setBounds(27, 414, 202, 23);
		contentPane.add(chk3);
		
		chk4 = new JCheckBox("Hair colour - Balayage");
		chk4.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk4.setForeground(new Color(255, 255, 255));
		chk4.setBackground(new Color(139, 69, 19));
		chk4.setBounds(27, 440, 202, 23);
		contentPane.add(chk4);
		
		chk5 = new JCheckBox("Hair spa");
		chk5.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk5.setForeground(new Color(255, 255, 255));
		chk5.setBackground(new Color(139, 69, 19));
		chk5.setBounds(27, 232, 202, 23);
		contentPane.add(chk5);
		
		chk6 = new JCheckBox("Nails - Gel Polish");
		chk6.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk6.setForeground(new Color(255, 255, 255));
		chk6.setBackground(new Color(139, 69, 19));
		chk6.setBounds(27, 258, 202, 23);
		contentPane.add(chk6);
		
		chk7 = new JCheckBox("Nails - Extensions");
		chk7.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk7.setForeground(new Color(255, 255, 255));
		chk7.setBackground(new Color(139, 69, 19));
		chk7.setBounds(27, 284, 202, 23);
		contentPane.add(chk7);
		
		chk8 = new JCheckBox("Manicure");
		chk8.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk8.setForeground(new Color(255, 255, 255));
		chk8.setBackground(new Color(139, 69, 19));
		chk8.setBounds(27, 310, 202, 23);
		contentPane.add(chk8);
		
		chk9 = new JCheckBox("Pedicure");
		chk9.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk9.setForeground(new Color(255, 255, 255));
		chk9.setBackground(new Color(139, 69, 19));
		chk9.setBounds(27, 336, 202, 23);
		contentPane.add(chk9);
		
		chk10 = new JCheckBox("ManiPedi Combo");
		chk10.setFont(new Font("Times New Roman", Font.BOLD, 17));
		chk10.setForeground(new Color(255, 255, 255));
		chk10.setBackground(new Color(139, 69, 19));
		chk10.setBounds(27, 206, 202, 23);
		contentPane.add(chk10);
		
		JButton remove = new JButton("REMOVE");
		remove.setFont(new Font("Times New Roman", Font.BOLD, 17));
		remove.setForeground(new Color(255, 255, 255));
		remove.setBackground(new Color(139, 69, 19));
		remove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel model= new DefaultTableModel();
				if (chk1.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }
		        }
		        if (chk2.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }
		        }
		        if (chk3.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }
		        }
		        if (chk4.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }
		        }
		        if (chk5.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }
		        }
		        if (chk6.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }
		        }
		        if (chk7.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }
		        }
		        if (chk8.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }
		        }
		        if (chk9.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");;
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }
		        }
		        if (chk10.isSelected()) {
		            int getSelectedRowForDeletion = jTable1.getSelectedRow();
		            if (getSelectedRowForDeletion >= 0) {
		                model.removeRow(getSelectedRowForDeletion);
		                JOptionPane.showMessageDialog(null, "SERVICE DELETED");
		            } else {
		                JOptionPane.showMessageDialog(null, "Unable to Delete");
		            }

		    }                                       
		    }
	
		   
				
				
			
		});
		remove.setBounds(27, 546, 202, 39);
		contentPane.add(remove);
		
		JButton add = new JButton("ADD");
		add.setFont(new Font("Times New Roman", Font.BOLD, 17));
		add.setForeground(new Color(255, 255, 255));
		add.setBackground(new Color(139, 69, 19));
		add.addActionListener(new ActionListener() {
			@SuppressWarnings("unused")
			private int price;

			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model= new DefaultTableModel();
				   int sum;
			        sum = 0;
			        if (chk1.isSelected()) {
			            String cut = chk1.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 450
			            });
			        }

			        if (chk2.isSelected()) {
			            String cut = chk2.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 399
			            });
			        }
			        if (chk3.isSelected()) {
			            String cut = chk3.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 5500
			            });
			        }

			        if (chk4.isSelected()) {
			            String cut = chk4.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 300
			            });
			        }

			        if (chk5.isSelected()) {
			            String cut = chk5.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 499
			            });
			        }
			        if (chk6.isSelected()) {
			            String cut = chk6.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 550
			            });
			        }
			        if (chk7.isSelected()) {
			            String cut = chk7.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 1899
			            });
			        }
			        if (chk8.isSelected()) {
			            String cut = chk8.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 450
			            });
			        }
			        if (chk9.isSelected()) {
			            String cut = chk9.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 500
			            });
			        }
			        if (chk10.isSelected()) {
			            String cut = chk10.getText();
			            model = (DefaultTableModel) jTable1.getModel();
			            model.addRow(new Object[]{
			                cut,
			                price = 999
			            });
			   
				
				for (int i = 0; i < jTable1.getRowCount(); i++) {
		            sum = sum + Integer.parseInt(jTable1.getValueAt(i, 1).toString());
		        }
		        txtsub.setText(String.valueOf(sum));
		    
		        }
				
			}
		});
		add.setBounds(27, 496, 202, 39);
		contentPane.add(add);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 239, 213));
		panel_1.setBounds(0, 596, 738, 162);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("SUBTOTAL");
		lblNewLabel_1.setForeground(new Color(102, 0, 0));
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1.setBounds(26, 6, 139, 30);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("PAYMENT");
		lblNewLabel_1_1.setForeground(new Color(102, 0, 0));
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1_1.setBounds(308, 6, 139, 30);
		panel_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("BALANCE");
		lblNewLabel_1_1_1.setForeground(new Color(102, 0, 0));
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1_1_1.setBounds(26, 62, 139, 30);
		panel_1.add(lblNewLabel_1_1_1);
		
		txtsub = new JTextField();
		txtsub.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		txtsub.setBounds(175, 10, 123, 30);
		panel_1.add(txtsub);
		txtsub.setColumns(10);
		
		txtpay = new JTextField();
		txtpay.setBounds(439, 9, 190, 30);
		panel_1.add(txtpay);
		txtpay.setColumns(10);
		
		txtbal = new JTextField();
		txtbal.setBounds(175, 62, 128, 30);
		panel_1.add(txtbal);
		txtbal.setColumns(10);
		
		JButton cal = new JButton("CALCULATE");
		cal.setFont(new Font("Times New Roman", Font.BOLD, 17));
		cal.setForeground(new Color(255, 255, 255));
		cal.setBackground(new Color(139, 69, 19));
		cal.addActionListener(new ActionListener() {
		

			public void actionPerformed(ActionEvent e) {
				int subtot = Integer.parseInt(txtsub.getText());
		        int pay = Integer.parseInt(txtpay.getText());		       
		        int bal = subtot - pay;
		        txtbal.setText(String.valueOf(bal));
				
			}
		});
		cal.setBounds(308, 51, 420, 41);
		panel_1.add(cal);
		
		BACK = new JButton("BACK");
		BACK.setFont(new Font("Times New Roman", Font.BOLD, 17));
		BACK.setForeground(new Color(255, 255, 255));
		BACK.setBackground(new Color(139, 69, 19));
		BACK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MAINMENU mm = new MAINMENU();
				mm.setVisible(true);
				dispose();
				
			}
		});
		BACK.setBounds(639, 3, 89, 23);
		panel_1.add(BACK);
		
		btnNewButton_2 = new JButton("EXIT");
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 17));
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setBackground(new Color(139, 69, 19));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				end en= new end();
				en.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(639, 28, 89, 23);
		panel_1.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("PROCEED TO PAYMENT");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PAYMENU py= new PAYMENU();
				py.setVisible(true);
				dispose();
			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 17));
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setBackground(new Color(139, 69, 19));
		btnNewButton_3.setBounds(10, 100, 718, 51);
		panel_1.add(btnNewButton_3);
		
		jTable1 = new JTable();
		jTable1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"New column", "New column"
			}
		));
		jTable1.setCellSelectionEnabled(true);
		jTable1.setColumnSelectionAllowed(true);
		jTable1.setBounds(256, 188, 482, 399);
		contentPane.add(jTable1);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("4_Beautyparlour1.zip\\images\\INV NEW.jpg"));
		lblNewLabel.setBounds(0, 0, 748, 208);
		contentPane.add(lblNewLabel);
	}
}

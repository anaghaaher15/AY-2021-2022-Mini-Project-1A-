package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;

public class loginpage extends JFrame {
	//Connection conn = null;
	//Connection conn = (Connection)DriverManager.getConnection("jdbc:mysql//localhost:3306/beautyparlourdb","root","Project@123");

	private JPanel contentPane;
	private JTextField txtuser;
	private JPasswordField txtpass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginpage frame = new loginpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public loginpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 690, 609);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("4_Beautyparlour1.zip\\images\\loginheader.jpg"));
		lblNewLabel.setBounds(-17, 0, 700, 297);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("LOGIN PAGE");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 46));
		lblNewLabel_1.setBounds(10, 308, 349, 49);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("USERNAME :");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1_1.setBounds(10, 368, 186, 49);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("PASSWORD :");
		lblNewLabel_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1_1_1.setBounds(10, 415, 349, 49);
		contentPane.add(lblNewLabel_1_1_1);
		
		txtuser = new JTextField();
		txtuser.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		txtuser.setColumns(10);
		txtuser.setBounds(181, 368, 483, 36);
		contentPane.add(txtuser);
		
		txtpass = new JPasswordField();
		txtpass.setBounds(181, 415, 483, 36);
		contentPane.add(txtpass);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MAINMENU mm=new MAINMENU();
				mm.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(102, 51, 0));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 23));
		btnNewButton.setBounds(10, 475, 316, 36);
		contentPane.add(btnNewButton);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				INVENTORY inv= new INVENTORY();
				inv.setVisible(true);
				dispose();
				
;				
			}
		});
		btnLogin.setForeground(Color.WHITE);
		btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 23));
		btnLogin.setBackground(new Color(102, 51, 0));
		btnLogin.setBounds(348, 475, 316, 36);
		contentPane.add(btnLogin);
		
		JButton btnNewButton_1 = new JButton("FORGOT PASSWORD?");
		btnNewButton_1.setBackground(new Color(139, 69, 19));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 17));
		btnNewButton_1.setBounds(10, 522, 654, 29);
		contentPane.add(btnNewButton_1);
	}
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package connection;
import java.sql.*;

/**
 *
 * @author User
 */
public class ConnectionProvider {
    public static Connection getCon(){
        Connection con = null;
        String host = "localhost";
        String port = "5432";
        String database = "Skinfit";
        String url = "jdbc:postgres://localhost:5432/Skinfit";
        String user = "postgres";
        String password = "Skinfit";
        
        try {
            
             Class.forName("org.postgresql.Driver");
            con=DriverManager.getConnection( "jdbc:postgresql://localhost:5432/SkinFit","postgres","Skinfit");
            if(con!=null){
                System.out.println("Connection OK");
            }
            else{
                System.out.println("Connection failed");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return con;
        }
    }
    

